<?php	
$path = '../';
include_once '../android/db-connect.php';
require_once($path."resources/config.php");

//inicamos la sesión
//session_start();

	//Conexión de BBDD
$db = conectarBBDD();

	//Para volver al registro
$url = "Location:" . ROOT_PATH . "horario/?msg_error=";

	//Para enviar la notificación
$notificacion='';

if($db)
{
	$numVariables = count($_REQUEST);
	$numVariables--;
	$numPlantas = $numVariables / 19;

	$dias = ["Lunes", "Martes", "Miércoles", "Jueves", "Viernes", "Sábado", "Domingo"];

	$biblioteca=$_REQUEST['Biblioteca'];

	for($i = 1; $i <= $numPlantas; $i++) {
		$planta = $_REQUEST[$i.'_NombrePlanta'];
		for($d = 0; $d < count($dias); $d++){
			$dia = $dias[$d];
			$dia_abre = $_REQUEST[$i.'_'.$dia.'_abre'];
			$dia_cierra = $_REQUEST[$i.'_'.$dia.'_cierra'];
			$sql="REPLACE INTO horarios VALUES('$biblioteca','$planta','$dia','$dia_abre','$dia_cierra')";
			$consulta=realizarConsultas($db,$sql);
		}
	}	

	//*NOTA ACLARATIVA*
	//Por convenio, se establece que:
		//Cuando el horario de un día determinado sea "CERRADO", se le asignará '11:11:11' a la hora de inicio y '00:00:00' a la hora de cierre.
		//Cuando el horario de un día determinado sea "TODO EL DÍA", se le asignará '23:59:59' a la hora de inicio y '00:00:00' a la hora de cierre.
	for($i = 0; $i < $longitud; $i = $i+3){
		$mas_uno=$i+1;
		$mas_dos=$i+2;
		$sql="REPLACE INTO horarios VALUES('$biblioteca','$Planta','$horario[$i]','$horario[$mas_uno]','$horario[$mas_dos]')";
		$consulta=realizarConsultas($db,$sql);
	}*/

	$notificacion .="Se ha guardado correctamente el nuevo horario";
}

else
{
	$notificacion .="El horario no se ha podido guardar. Contacte con el adminsitrador.";
}

//Cerramos la conexión
desconectarBBDD($db);

//Concateno el mensaje
$url= $url . $notificacion;

//Volvemos a la url que nos solicitó
header($url);
?>