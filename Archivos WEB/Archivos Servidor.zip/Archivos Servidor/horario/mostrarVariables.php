<!--Incluimos funciones del header -->
<?php
$path = '../';
require_once($path."resources/config.php");
?>

<!doctype html>
<html lang="es">
<head>
	<meta http-equiv="Content-Type" content="text/html;charset=utf-8">
	<meta charset="UTF-8">
	<title>Montevicho</title>
	<meta name="author" content="Montevicho">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
	<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
	
	<?php
	echo anadirCSSComunes(); 
	?>
	<!-- Google ReCaptcha-->
	<script src='https://www.google.com/recaptcha/api.js'></script>
</head>

<body>
	<!-- Cabecera -->
	<?php 
	require(TEMPLATES_PATH.'header.php');
	?>	
	
	<!--  Contenido  -->

	<div class="container">
		<div id="content">
			<?php print_r($_REQUEST); ?>
		</div>
	</div>

	<!-- Footer -->
	<?php
	require_once(TEMPLATES_PATH.'footer.php');
	?>

	<!-- Scripts JavaScript-->
	<?php echo anadirJSComunes(); ?>
	<script>
		function abrirPlanta(evt, nombrePlanta) {
			var i, x, tablinks;
			x = document.getElementsByClassName("planta");
			for (i = 0; i < x.length; i++) {
				x[i].style.display = "none";
			}
			tablinks = document.getElementsByClassName("tablink");
			for (i = 0; i < x.length; i++) {
				tablinks[i].className = tablinks[i].className.replace(" w3-red", "");
			}
			document.getElementById(nombrePlanta).style.display = "block";
			evt.currentTarget.className += " w3-red";
		}
	</script>

</body>
</html>