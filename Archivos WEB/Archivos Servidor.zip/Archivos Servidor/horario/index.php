<!--Incluimos funciones del header -->
<?php
$path = '../';
require_once($path."resources/config.php");
?>

<!doctype html>
<html lang="es">
<head>
	<meta charset="UTF-8">
	<title>Horario</title>
	<meta name="author" content="Montevicho">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
	
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>


	<?php
	echo anadirJS('horario.js');
	echo anadirCSSComunes();
	echo anadirCSS('horario.css');	
	echo anadirJS('localizacion.js');
	?>
	<script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyDvC2agj3PhxniAuukdznJ1lIaipXxGrpY&callback=myMap"></script>
	<!-- Google ReCaptcha-->
	<script src='https://www.google.com/recaptcha/api.js'></script>
</head>

<body>
	<!-- Cabecera -->
	<?php 
	require(TEMPLATES_PATH.'header.php');
	?>	
	
	<!--  Contenido  -->

	<div class="container">	
		<div id="content">
			
			<?php
			//Nos conectamos a la base de datos del servidor
			$db =conectarBBDD();
			if ( mysqli_connect_errno() ) {
				echo "Error de conexión a la BD: ".mysqli_connect_error();
				exit();
			}

			$Biblioteca=$_SESSION['biblioteca'];

			//realizo la consulta por defecto
			$sql="SELECT planta, dia, hora_inicio, hora_fin FROM horarios WHERE biblioteca='$Biblioteca' ORDER BY planta, CASE dia WHEN 'Lunes' THEN 0 WHEN 'Martes' THEN 1 WHEN 'Miércoles' THEN 2 WHEN 'Jueves' THEN 3 WHEN 'Viernes' THEN 4 WHEN 'Sábado' THEN 5 WHEN 'Domingo' THEN 6 ELSE dia END";

			//hago la consulta:
			$consulta_horarios=realizarConsulta($db,$sql);
			

			if ($consulta_horarios->num_rows==0){ //No hay ningún horario definido, de modo que mostraremos una plantilla inicial para establecerlos
				?>
				<div id="barraPlantas" class="w3-bar w3-black">
					<button id="boton1" class="w3-bar-item w3-button tablink w3-red" onclick="abrirPlanta(event,'planta1');">Planta 1</button>
					<button id="botonAnadirPlanta" class="w3-bar-item w3-button"><i class="fa fa-plus" aria-hidden="true"></i>Añadir otra planta</button>
				</div>
				
				<form method="post" name="form_Predeterminado" action="guardarHorario.php"> <!-- guardarHorario | mostrarVariables-->
					<input type="hidden" name="Biblioteca" value="<?php echo"$Biblioteca";?>">
					<div id="planta1" class="w3-container planta">
						<!-- <input id="varPlantaHidden" type="hidden" name="planta1" value="planta1"> -->
						<div class="tooltipw3"><i id="pencil-edit" class="fa fa-pencil-square-o" aria-hidden="true"></i><span class="tooltiptext tooltip-bottom w3-padding">Indica el nombre con el que se identificará la planta</span></div><input id="nombrePlanta" class="w3-margin-top w3-margin-bottom" type="text" name="1_NombrePlanta" placeholder="Nombre de la planta" value="Planta 1" required/> 
							<div class="w3-row">
								<table class="w3-table w3-centered">
									<?php
									$dias = ["Lunes", "Martes", "Miércoles", "Jueves", "Viernes", "Sábado", "Domingo"];
									?>
									<tr>
										<th></th>
										<th>Lunes</th>
										<th>Martes</th>
										<th>Miércoles</th>
										<th>Jueves</th>
										<th>Viernes</th>
										<th>Sábado</th>
										<th>Domingo</th>
									</tr>
									<tr>
										<td>Apertura</td>
										<?php for($i = 0; $i < count($dias); $i++){
											?>
											<td>
												<?php $dia_abre = "1_$dias[$i]_abre";?>
												<select id=<?php echo $dias[$i];?>_abre name=<?php echo $dia_abre;?> onchange="selectDisabled()">
													<option value="11:11:11">Cerrado</option>
													<option value="23:59:59">Todo el día</option>
													<?php
													for($h = 0; $h < 24; $h++){
														if($h < 10){
															if($h == 9){
																echo "<option value='0$h:00:00' selected>0$h:00</option>";
															}
															else{
																echo "<option value='0$h:00:00'>0$h:00</option>";
															}
															echo "<option value='0$h:30:00'>0$h:30</option>";
														}
														else{
															echo "<option value='$h:00:00'>$h:00</option>";
															echo "<option value='$h:30:00'>$h:30</option>";
														}
													}
													?>
												</select>
											</td>
											<?php } ?>
										</tr>
										<tr>
											<td>Cierre</td>
											<?php for($i = 0; $i < count($dias); $i++){
												?>
												<td>
													<?php $dia_cierra = "1_$dias[$i]_cierra";?>
													<select id=<?php echo $dias[$i];?>_cierra name=<?php echo $dia_cierra;?>>
														<option hidden value="11:11:11">Cerrado</option>
														<option hidden value="23:59:59">Todo el día</option>
														<?php
														for($h = 0; $h < 24; $h++){
															if($h < 10){
																echo "<option value='0$h:00:00'>0$h:00</option>";
																echo "<option value='0$h:30:00'>0$h:30</option>";
															}
															else{
																if($h == 21){
																	echo "<option value='$h:00:00' selected>$h:00</option>";
																}
																else{
																	echo "<option value='$h:00:00'>$h:00</option>";
																}
																echo "<option value='$h:30:00'>$h:30</option>";
															}
														}
														?>
													</select>
												</td>
												<?php } ?>
											</tr>
										</table>
										<div class="w3-margin-top">
											<h3>Añadir horario especial</h3>
											<div class="w3-container">
												<div class="w3-content">
													<div class="w3-col s2"><h5>Desde:</h5></div>
													<div class="input-group">
														<span class="input-group-addon"><i class="fa fa-calendar-o fa" aria-hidden="true"></i></span>
														<input id="FechaEspecial_desde" type="date" class="form-control" name="1_FechaEspecial_desde" />
													</div>	
												</div>
												<div class="w3-content w3-margin-top">
													<div class="w3-col s2"><h5>Hasta:</h5></div>
													<div class="input-group">
														<span class="input-group-addon"><i class="fa fa-calendar-o fa" aria-hidden="true"></i></span>
														<input id="FechaEspecial_hasta" type="date" class="form-control" name="1_FechaEspecial_hasta" />
													</div>	
												</div>
												<div class="w3-margin w3-margin-left">
													<span>Apertura:</span>
													<select id="FechaEspecial_abre" name="1_FechaEspecial_abre">
														<option value="cerrado">Cerrado</option>
														<option value="todo-el-dia">Todo el día</option>
														<?php
														for($h = 0; $h < 24; $h++){
															if($h < 10){
																if($h == 9){
																	echo "<option value='0$h:00:00' selected>0$h:00</option>";
																}
																else{
																	echo "<option value='0$h:00:00'>0$h:00</option>";
																}
																echo "<option value='0$h:30:00'>0$h:30</option>";
															}
															else{
																echo "<option value='$h:00:00'>$h:00</option>";
																echo "<option value='$h:30:00'>$h:30</option>";
															}



														}
														?>
													</select>

													<span>Cierre:</span>
													<select id="FechaEspecial_cierra" name="1_FechaEspecial_cierra">
														<?php
														for($h = 0; $h < 24; $h++){
															if($h < 10){
																echo "<option value='0$h:00:00'>0$h:00</option>";
																echo "<option value='0$h:30:00'>0$h:30</option>";
															}
															else{
																if($h == 21){
																	echo "<option value='$h:00:00' selected>$h:00</option>";
																}
																else{
																	echo "<option value='$h:00:00'>$h:00</option>";
																}
																echo "<option value='$h:30:00'>$h:30</option>";
															}
														}
														?>
													</select>
												</div>
											</div>
											<div class="w3-container w3-margin-top">
												<button>+</button>
											</div>
										</div>



									</div>
								</div>
								<div id="botonEnviar" class="w3-content w3-center">
									<input id="submit" type="submit">
								</div>
							</form>


							<?php
						}
//CAMBIAR EL NOMBRE DE LA PESTAÑA SI SE CAMBIA EL NOMBRE DE LA PLANTA





















//TRASPONER LA TABLA
//CAMBIAR Y ADAPTAR NOMBRE DE VARIABLES (PONIENDO AL PRINCIPIO EL NOMBRE DE LA TABLA)
						else { 
					//Comprobamos cuantas plantas hay para mostrarlas en la barra de pestañas
							$sql_plantas = "SELECT DISTINCT planta FROM horarios WHERE biblioteca='$Biblioteca' ORDER BY planta ASC";
							$consulta_plantas=realizarConsulta($db,$sql_plantas);
							?>

							<div id="barraPlantas" class="w3-bar w3-black">
								<?php
								$primeraPestaña = True;
						while ($planta = $consulta_plantas->fetch_assoc()){ //recorremos todas las plantas
							if($primeraPestaña == True){
								$primeraPestaña = False;?>
								<button class="w3-bar-item w3-button tablink w3-red" onclick="abrirPlanta(event,'<?php echo $planta["planta"];?>')"><?php echo $planta["planta"];?></button>
								<?php }
								else { ?>
								<button class='w3-bar-item w3-button tablink' onclick="abrirPlanta(event,'<?php echo $planta["planta"];?>')"><?php echo $planta["planta"];?></button>
								<?php
							}?>
							
							<?php
						}
						?>
						<button id="botonAnadirPlanta" class="w3-bar-item w3-button"><i class="fa fa-plus" aria-hidden="true"></i>Añadir otra planta</button>
					</div>
					<form method="post" name="form_<?php echo $planta["planta"];?>" action="guardarHorario.php">
												<input type="hidden" name="Biblioteca" value="<?php echo"$Biblioteca";?>">
					<?php
					$consulta_plantas_2=realizarConsulta($db,$sql_plantas);
					$primeraPlanta = True;
					$num = 0;
							while ($planta = $consulta_plantas_2->fetch_assoc()){ //recorremos todas las plantas
								$num++;
								$p = $planta["planta"];
								$sql_horas="SELECT dia, hora_inicio, hora_fin FROM horarios WHERE biblioteca='$Biblioteca' and planta='$p' ORDER BY CASE dia WHEN 'Lunes' THEN 0 WHEN 'Martes' THEN 1 WHEN 'Miércoles' THEN 2 WHEN 'Jueves' THEN 3 WHEN 'Viernes' THEN 4 WHEN 'Sábado' THEN 5 WHEN 'Domingo' THEN 6 ELSE dia END";
									if($primeraPlanta == True){
										$primeraPlanta = False; ?>
									<div id="<?php echo $planta["planta"];?>" class="w3-container planta">
										<?php }
										else { ?>
										<div id="<?php echo $planta["planta"];?>" class="w3-container planta" style="display:none">
											<?php } ?>
											
												<div class="tooltipw3"><i id="pencil-edit" class="fa fa-pencil-square-o" aria-hidden="true"></i><span class="tooltiptext tooltip-bottom w3-padding">Indica el nombre con el que se identificará la planta</span></div><input id="nombrePlanta" class="w3-margin-top w3-margin-bottom" type="text" name="<?php echo $num;?>_NombrePlanta" placeholder="Nombre de la planta" value="<?php echo $planta["planta"];?>" required/>
												<div class="w3-row">
													<table class="w3-table w3-centered">
														<?php
														$dias = ["Lunes", "Martes", "Miércoles", "Jueves", "Viernes", "Sábado", "Domingo"];
														?>
														<tr>
															<th></th>
															<th>Lunes</th>
															<th>Martes</th>
															<th>Miércoles</th>
															<th>Jueves</th>
															<th>Viernes</th>
															<th>Sábado</th>
															<th>Domingo</th>
														</tr>
														<tr>
															


														<td>Apertura</td>
														<?php
														$consulta_horas_2=realizarConsulta($db,$sql_horas);
														while ($diaPlanta_2 = $consulta_horas_2->fetch_assoc()){	?>
															<td>
																<?php $dia_abre = $num."_".$diaPlanta_2["dia"]."_abre"; ?>
																<select id=<?php echo $diaPlanta_2["dia"];?>_abre name=<?php echo $dia_abre;?> onchange="selectDisabled()">
																	<option value="11:11:11">Cerrado</option>
																<option value="23:59:59">Todo el día</option>
																<?php
																if ("11:11:11" == $diaPlanta_2["hora_inicio"]){
																	echo "<option hidden value='11:11:11' selected>Cerrado</option>";
																}
																if ("23:59:59" == $diaPlanta_2["hora_inicio"]){
																	echo "<option hidden value='23:59:59' selected>Todo el día</option>";
																}	
																for($h = 0; $h < 24; $h++){
																	if($h < 10){
																		if("0$h:00:00" == $diaPlanta_2["hora_inicio"]){
																			echo "<option value='0$h:00:00' selected>0$h:00</option>";
																			echo "<option value='0$h:30:00'>0$h:30</option>";
																		}
																		else if ("0$h:30:00" == $diaPlanta_2["hora_inicio"]){
																			echo "<option value='0$h:00:00'>0$h:00</option>";
																			echo "<option value='0$h:30:00' selected>0$h:30</option>";
																		}
																		else{
																			echo "<option value='0$h:00:00'>0$h:00</option>";
																			echo "<option value='0$h:30:00'>0$h:30</option>";
																		}

																	}
																	else{
																		if("$h:00:00" == $diaPlanta_2["hora_inicio"]){
																			echo "<option value='$h:00:00' selected>$h:00</option>";
																			echo "<option value='$h:30:00'>$h:30</option>";
																		}
																		else if ("$h:30:00" == $diaPlanta_2["hora_inicio"]){
																			echo "<option value='$h:00:00'>$h:00</option>";
																			echo "<option value='$h:30:00' selected>$h:30</option>";
																		}
																		else{
																			echo "<option value='$h:00:00'>$h:00</option>";
																			echo "<option value='$h:30:00'>$h:30</option>";
																		}
																	}
																}
																?>
																</select>
															</td>
															<?php } ?>
														</tr>







														<tr>
														<td>Cierre</td>
														<?php
														$consulta_horas=realizarConsulta($db,$sql_horas);
														while ($diaPlanta = $consulta_horas->fetch_assoc()){	?>
															<td>
																<?php $dia_cierra = $num."_".$diaPlanta["dia"]."_cierra"; ?>
																<select id=<?php echo $diaPlanta["dia"];?>_abre name=<?php echo $dia_cierra;?> onchange="selectDisabled()">
																	<option value="11:11:11">Cerrado</option>
																<option value="23:59:59">Todo el día</option>
																<?php
																if ("11:11:11" == $diaPlanta["hora_fin"]){
																	echo "<option hidden value='11:11:11' selected>Cerrado</option>";
																}
																if ("23:59:59" == $diaPlanta["hora_fin"]){
																	echo "<option hidden value='23:59:59' selected>Todo el día</option>";
																}	
																for($h = 0; $h < 24; $h++){
																	if($h < 10){
																		if("0$h:00:00" == $diaPlanta["hora_fin"]){
																			echo "<option value='0$h:00:00' selected>0$h:00</option>";
																			echo "<option value='0$h:30:00'>0$h:30</option>";
																		}
																		else if ("0$h:30:00" == $diaPlanta["hora_fin"]){
																			echo "<option value='0$h:00:00'>0$h:00</option>";
																			echo "<option value='0$h:30:00' selected>0$h:30</option>";
																		}
																		else{
																			echo "<option value='0$h:00:00'>0$h:00</option>";
																			echo "<option value='0$h:30:00'>0$h:30</option>";
																		}

																	}
																	else{
																		if("$h:00:00" == $diaPlanta["hora_fin"]){
																			echo "<option value='$h:00:00' selected>$h:00</option>";
																			echo "<option value='$h:30:00'>$h:30</option>";
																		}
																		else if ("$h:30:00" == $diaPlanta["hora_fin"]){
																			echo "<option value='$h:00:00'>$h:00</option>";
																			echo "<option value='$h:30:00' selected>$h:30</option>";
																		}
																		else{
																			echo "<option value='$h:00:00'>$h:00</option>";
																			echo "<option value='$h:30:00'>$h:30</option>";
																		}
																	}
																}
																?>
																</select>
															</td>
															<?php } ?>
													</tr>
											

													</table>
													<div class="w3-margin-top">
														<h3>Añadir horario especial</h3>
														<div class="w3-container">
															<div class="w3-content">
																<div class="w3-col s2"><h5>Desde:</h5></div>
																<div class="input-group">
																	<span class="input-group-addon"><i class="fa fa-calendar-o fa" aria-hidden="true"></i></span>
																	<input type="date" class="form-control" name="FechaEspecial_desde" id="FechaEspecial_desde" />
																</div>	
															</div>
															<div class="w3-content w3-margin-top">
																<div class="w3-col s2"><h5>Hasta:</h5></div>
																<div class="input-group">
																	<span class="input-group-addon"><i class="fa fa-calendar-o fa" aria-hidden="true"></i></span>
																	<input type="date" class="form-control" name="FechaEspecial_hasta" id="FechaEspecial_hasta" />
																</div>	
															</div>
															<div class="w3-margin w3-margin-left">
																<span>Apertura:</span>
																<select name="FechaEspecial_abre">
																	<option value="cerrado">Cerrado</option>
																	<option value="todo-el-dia">Todo el día</option>
																	<?php
																	for($h = 0; $h < 24; $h++){
																		if($h < 10){
																			if($h == 9){
																				echo "<option value='0$h:00:00' selected>0$h:00</option>";
																			}
																			else{
																				echo "<option value='0$h:00:00'>0$h:00</option>";
																			}
																			echo "<option value='0$h:30:00'>0$h:30</option>";
																		}
																		else{
																			echo "<option value='$h:00:00'>$h:00</option>";
																			echo "<option value='$h:30:00'>$h:30</option>";
																		}



																	}
																	?>
																</select>

																<span>Cierre:</span>
																<select name="FechaEspecial_cierra">
																	<?php
																	for($h = 0; $h < 24; $h++){
																		if($h < 10){
																			echo "<option value='0$h:00:00'>0$h:00</option>";
																			echo "<option value='0$h:30:00'>0$h:30</option>";
																		}
																		else{
																			if($h == 21){
																				echo "<option value='$h:00:00' selected>$h:00</option>";
																			}
																			else{
																				echo "<option value='$h:00:00'>$h:00</option>";
																			}
																			echo "<option value='$h:30:00'>$h:30</option>";
																		}
																	}
																	?>
																</select>
															</div>
														</div>
														<div class="w3-container w3-margin-top">
															<button>+</button>
														</div>
													</div>

												</div>
											</div>

										<?php
									
								}?>
								<div id="botonEnviar" class="w3-content w3-center">
									<input id="submit" type="submit">
								</div>
							</form>
							<?php }

							?>
			</div>
		</div>
	</body>

	<!-- MAPA -->
	<div id="googleMap" style="width:100%;height:450px;"></div>
	<?php 
	$sql1="SELECT nombre, SE_Lon, SE_Lat FROM bibliotecas WHERE siglas='$Biblioteca'";
	$consulta_biblioteca=realizarConsulta($db,$sql1);
	$biblio = $consulta_biblioteca->fetch_assoc();
	$nombre=$biblio["nombre"];
	$lon=$biblio["SE_Lon"];
	$lan=$biblio["SE_Lat"];

	echo "<script>";
	echo "myMap('".$nombre."',".$lon.",".$lan.")"; 
	echo "</script>";
	?>


	<!-- Footer -->
	<?php
	require_once(TEMPLATES_PATH.'footer.php');
	?>

	<!-- Scripts JavaScript-->
	<?php echo anadirJSComunes();?>
	<script>// Click on the first tablink on load
	document.getElementsByClassName("tablink")[0].click();
</script>
</html>