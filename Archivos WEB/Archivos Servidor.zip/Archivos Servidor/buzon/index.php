﻿<?php
	$path = '../';	
	require_once($path."resources/config.php");
?>
<!doctype html>
<html lang="es">
<head>
	<meta http-equiv="Content-Type" content="text/html;charset=utf-8">
	<meta charset="UTF-8">
	<title>Buzón de sugerencias</title>
	<meta name="author" content="Montevicho">
	<meta name="viewport" content="width=device-width, initial-scale=1">
  <?php
  echo anadirCSS('buzon.css');
  echo anadirCSSComunes();
 
  echo '<link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">' . PHP_EOL;
  ?>
</head>
<body>	
<!-- Cabecera -->
	<?php
 	require_once(TEMPLATES_PATH.'header.php');
	?>	
	
<!--  Contenido  -->

	<?php if(estaLogueado()) : ?>

		<div class="container">
			<div id="content">
				<div class="well margin-top30 fg-form margin">
				<!--Cuando pulsas en mensajes enviados-->
					<table class="table table-sm">
						<table class="table table-striped">
							<thead class ="fondo_celda">
								<tr>
									
									<th class ="letraMax">Respondido</th>
									<th class ="letraMax">Fecha</th>
									<th class ="letraMax">Asunto</th>
									
								</tr>
							</thead>
							<tbody>
								<?php
								$usuario=$_SESSION['biblioteca'];
								$sql="SELECT idMensaje,email,fecha ,contenido,asunto FROM envia WHERE respuesta=0 and biblioteca='$usuario' ORDER BY fecha desc";
								$consulta=mysqli_query($db, $sql);
								$MENSAJES_PAGINA=10;// solo se van a mostrar 10 mensajes de usuario por pagina
								//examino la pagina a mostrar y el inicio del registro a mostrar, con esto iniciaremos la pagina 
								if(isset($_GET["pagina"])){
									$pagina=$_GET["pagina"];
								}
								if (!isset($_GET["pagina"])){
									$inicio=0;
									$pagina=1;
								}
								else{
									$inicio= ($pagina-1)*$MENSAJES_PAGINA;
								}
								$numMensajes=$consulta->num_rows;
								//calculo el total de paginas
								$total_paginas = ceil($numMensajes/$MENSAJES_PAGINA);
								//ordenamos la consulta por mensajes de fecha mas reciente y ponemos el limite de 10 mensajes por pagina
								$sql .=" LIMIT ".$inicio."," . $MENSAJES_PAGINA;
								
								$consulta_pagina=realizarConsulta($db,$sql);
								$contador=1;
								$fila=mysqli_fetch_object($consulta_pagina);
								
								while ($fila!=NULL){
									//para saber si ya se ha contestado el mensaje
									$sql1="SELECT * FROM envia WHERE idMensaje=$fila->idMensaje";
									$consulta1=mysqli_query($db, $sql1);
									$coincidencias=$consulta1->num_rows;
									echo "<tr>";
									//si no he contestado
									if ($coincidencias==1){
										echo "<td><span class='glyphicon glyphicon-unchecked'></span></td>";
									}			
									//si lo he contestado
									else{
										echo "<td><span class='glyphicon glyphicon-check'></span></td>";
									}
									echo "<td  class ='letra'>"; echo "$fila->fecha";echo "</td>";
									echo "<td class ='letra'>"; echo "$fila->asunto";echo "</td>";
									?>
									<td><button class="btn btn-default" data-toggle="modal" data-target="#<?php echo $contador;?>">Mostrar</button></td>
									<?php
									echo "</tr>";
									?>
									<!--Pop up Contestar-->
									<div class="modal fade" id="<?php echo $contador;?>" role="dialog">
										<div class="modal-dialog">
											<div class="modal-content">
												<div class="modal-header">
														<button type="button" class="close" data-dismiss="modal">Cerrar</button>
														<h2 class="modal-title">Mensaje recibido</h2>
														<small class="pull-right time"><i class="fa fa-clock-o"></i> <?php  echo $fila->fecha; ?></small>
												</div>
												<div class="form-group ajustar col-lg-10"><?php echo $fila->contenido;?></div>
												<?php if ($coincidencias==1){//muestro para completar el mensaje?>
													<!-- Modal content-->
													<div class="modal-header">
														<h2 class="modal-title">Contestar</h2>
													</div>
													<form action="enviarContestacion.php" method="post" enctype="multipart/form-data">
													<input type="hidden" name="email" value="<?php echo $fila->email; ?>" />
													<input type="hidden" name="idMensaje" value="<?php echo $fila->idMensaje; ?>" />
													<input type="hidden" name="asunto" value="<?php echo $fila->asunto; ?>" />
													<div class="modal-body">
														<div class="row">
														<!--Campo de mensaje-->
															<div class="col-md-12">
																<div class="form-group ">
																	<label for="mensaje" class ="titulos">Mensaje:</label>
																	<textarea id="form_message" name="mensaje" class="form-control" placeholder="Escribe tu mensaje..." rows="4" required="required" data-error="Please,leave us a message."></textarea>
																	<div class="help-block with-errors"></div>
																</div>
															</div>
															<div class="form-group ">
																<div class="col-xs-9">
																	<input type="submit" class="btn btn-primary" name="enviar" value="Enviar">
																	<input type="reset" class="btn btn-default" value="Borrar">
																</div>
															</div>
														</div>
													</div>
													</form>
												<?php }
												else{ //muestro el mensaje que o puse 
													$sql2="SELECT * FROM envia WHERE respuesta=1 and idMensaje=$fila->idMensaje";
													$consulta2=mysqli_query($db, $sql2);
													$fila2=mysqli_fetch_object($consulta2);	
													?>
													<div class="modal-header">
														<h2 class="modal-title">Mensaje contestado</h2>
														<small class="pull-right time"><i class="fa fa-clock-o"></i> <?php  echo $fila2->fecha; ?></small>
													</div>
													<div class="form-group ajustar col-lg-10"><?php echo $fila2->contenido; ?></div>
													
												<?php }?>
												<div class="modal-footer">
												</div>
											</div>
										</div>
									</div>
									<?php
								
									$fila=mysqli_fetch_object($consulta_pagina);	
									$contador++;
								}	
									?>
							</tbody>
						</table>
					</table>        
				</div>
				<!--paginador-->
				<?php 
				//para redireccionar las paginas
				if ($total_paginas > 1) {
					echo "<div class='w3-center'>";
					echo "<div class='w3-center w3-padding-32'>";
					echo"<div class='w3-bar'>";
				   if ($pagina != 1)
					  echo '<a href="'.ROOT_PATH . 'buzon/index.php'.'?&pagina='.($pagina-1).'" class="w3-bar-item w3-button w3-hover-theme">«</a>';
					  for ($i=1;$i<=$total_paginas;$i++) {
						if ($pagina == $i)
							//si muestro el índice de la página actual, no coloco enlace
							echo "<div class='w3-bar-item w3-hover-theme'>$pagina</div>";
						else
							//si el índice no corresponde con la página mostrada actualmente,
							//coloco el enlace para ir a esa página
							echo '<a href="'.ROOT_PATH . 'buzon/index.php'.'?&pagina='.$i.'" class="w3-bar-item w3-button w3-hover-theme">'.$i.'</a>';
					  }
					  if ($pagina != $total_paginas)
						echo '<a href="'.ROOT_PATH . 'buzon/index.php'.'?&pagina='.($pagina+1).'" class="w3-bar-item w3-button w3-hover-theme">»</a>';
					echo"</div>";
					echo"</div>";
					echo"</div>";
				}
				?>
			</div>
			</div>
		</div>

	<?php else : ?>
		<?php
		$url= "Location:".ROOT_PATH;
		header($url);
		?>

	<?php endif; ?>

	<!-- Footer -->
	<?php
 	require_once(TEMPLATES_PATH.'footer.php');
	?>	
	
	<!-- Scripts JavaScript-->
	<?php
	echo anadirJSComunes();
	echo anadirJS('popupmensaje.js');	
	?>
</body>
</html>