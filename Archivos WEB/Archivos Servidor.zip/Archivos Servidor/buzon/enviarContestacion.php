<?php
//Llamada al archivo de configuración
$path = '../';
require_once($path."resources/config.php");

//inicamos la sesión
session_start();

//URL para el redireccionamiento
$url='Location:'  . ROOT_PATH . 'buzon/';

//Conecto a la BBDD
$db =conectarBBDD();

//Si ocurre un error en la conexión
if(!$db)
{
	$mensajes = "msg_error=" . "Se ha producido un error con la conexión";
	
	//Volvemos a la url que nos solicitó
	header($url . $mensajes);
}

//Recogemos todas las variables POST 
$usuario=$_SESSION['biblioteca'];
$email= $_POST['email'];
$mensaje= $_POST['mensaje'];
$idMensaje=$_POST['idMensaje'];
$asunto=$_POST['asunto'];

$sql1="insert into envia values('$email','$usuario',now(),1,'$asunto','$mensaje','$idMensaje')";
$consulta1=mysqli_query($db, $sql1);
echo $sql1;
//Desconectamos de la BBDD
desconectarBBDD($db);

//Volvemos a la url que nos solicitó
header($url . $mensajes);
?>