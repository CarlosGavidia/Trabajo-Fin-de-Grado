function numPlantas() {
	num = document.getElementsByClassName("planta");
	return num.length;
}

function abrirPlanta(evt, nombrePlanta) {
	//alert(nombrePlanta);
	//alert("abrirPlanta");
	var i, x, tablinks;
	x = document.getElementsByClassName("planta");
	for (i = 0; i < x.length; i++) {
		x[i].style.display = "none";
	}
	tablinks = document.getElementsByClassName("tablink");
	for (i = 0; i < x.length; i++) {
		tablinks[i].className = tablinks[i].className.replace(" w3-red", "");
	}
	document.getElementById(nombrePlanta).style.display = "block"; 
	evt.currentTarget.className += " w3-red";
}

$(document).ready(function(){
	$("#botonAnadirPlanta").click(function(){
		$("#botonEnviar").before($(".planta:first").clone(true)); //Creo la nueva planta a partir de la predeterminada
		//x = $('[id=planta1]'); //Obtengo todos los elementos que tengan como id="planta1"
		var num = numPlantas(); //Cuento el número de plantas que hay, y ese número será el de la planta nueva
		num = num.toString();

		newId = "planta".concat(num); //Creo la id de la nueva planta
		var texto = "Planta ".concat(num); //El texto que tendrá el botón de la barra de esta nueva planta

		$(".planta:last").attr("id", newId); //Le cambio el id a la planta nueva
		
		//Proceso para crear el elemento HTML que será el botón de la nueva planta
		var primeraComilla = "'".concat(newId);
		var idComillas = primeraComilla.concat("'"); //Le pongo comillas simples a la nueva id
		var parte1 = "abrirPlanta(event, ".concat(idComillas);
		var todo = parte1.concat(");"); //La llamada a la función abrirPlanta con la planta nueva
		var idBoton = "boton".concat(num);
		var boton = $("<button></button>").attr({"id" : idBoton, "class" : "w3-bar-item w3-button tablink w3-red", "onclick" : todo}); //Código HTML del botón de la planta nueva
		boton.text(texto); //Le añado el texto
		$("#botonAnadirPlanta").before(boton); //Inserto el botón en la barra

		//Asigno los valores correspondientes a los distintos campos del formulario
			//Nombre de la planta
			var almohadillaPlanta = "#".concat(newId);
			var inputNombrePlanta = $(almohadillaPlanta).find("#nombrePlanta");
			inputNombrePlanta.attr("name", num.concat("_NombrePlanta"));
			inputNombrePlanta.val(texto);

			//Horas de apertura y cierre
			var dias = ["Lunes", "Martes", "Miércoles", "Jueves", "Viernes", "Sábado", "Domingo"];
			var abre = "_abre";
			var cierra = "_cierra";

			for(i = 0; i < dias.length; i++){
				var dia_abre = dias[i].concat(abre);
				var _dia_abre = "#".concat(dia_abre);
				var dia_cierra = dias[i].concat(cierra);
				var _dia_cierra = "#".concat(dia_cierra);

				var elemDiaAbre = $(almohadillaPlanta).find(_dia_abre);
				elemDiaAbre.attr("name", num.concat("_".concat(dia_abre)));
				var elemDiaCierra = $(almohadillaPlanta).find(_dia_cierra);
				elemDiaCierra.attr("name", num.concat("_".concat(dia_cierra)));
			}

			//Horarios especiales
			var fechaEspecial_desde = $(almohadillaPlanta).find("#FechaEspecial_desde");
			fechaEspecial_desde.attr("name", num.concat("_".concat("FechaEspecial_desde")));
			var fechaEspecial_hasta = $(almohadillaPlanta).find("#FechaEspecial_hasta");
			fechaEspecial_hasta.attr("name", num.concat("_".concat("FechaEspecial_hasta")));
			var fechaEspecial_abre = $(almohadillaPlanta).find("#FechaEspecial_abre");
			fechaEspecial_abre.attr("name", num.concat("_".concat("FechaEspecial_abre")));
			var fechaEspecial_cierra = $(almohadillaPlanta).find("#FechaEspecial_cierra");
			fechaEspecial_cierra.attr("name", num.concat("_".concat("FechaEspecial_cierra")));


		document.getElementById(idBoton).click();
	});


	$("#submit").click(function(){
			var select = $("select").attr("disabled", false);
	});
});


function selectDisabled() {
	var num = numPlantas();
	var dias = ["Lunes", "Martes", "Miércoles", "Jueves", "Viernes", "Sábado", "Domingo"];
	var abre = "_abre";
	var cierra = "_cierra";
	for(x = 1; x <= num; x++){	
		for(i = 0; i < dias.length; i++){
			var n = x.toString();
			var dia_abre = n.concat("_");
			var dia_cierra = n.concat("_");
			dia_abre = dia_abre.concat(dias[i].concat(abre));
			dia_cierra = dia_cierra.concat(dias[i].concat(cierra));
			//alert(document.getElementsByName(dia_abre)[0].value);
			if(document.getElementsByName(dia_abre)[0] != null){
				if(document.getElementsByName(dia_abre)[0].value == "11:11:11"){ //Si se ha seleccionado la opción "Cerrado":
					document.getElementsByName(dia_cierra)[0].value = "11:11:11"; //también se selecciona "Cerrado" en el cierre
					//alert(document.getElementsByName(dia_cierra)[0].value);
					document.getElementsByName(dia_cierra)[0].disabled = true;
					
				}
				else if(document.getElementsByName(dia_abre)[0].value == "23:59:59"){
					document.getElementsByName(dia_cierra)[0].value = "23:59:59";
					document.getElementsByName(dia_cierra)[0].disabled = true;
				}
				else if(document.getElementsByName(dia_cierra)[0].value == "11:11:11" || document.getElementsByName(dia_cierra)[0].value == "23:59:59"){
					document.getElementsByName(dia_cierra)[0].value = "21:00:00";
					document.getElementsByName(dia_cierra)[0].disabled = false;
				}
			}
		}
	}
}
/*
$(document).ready(function(){
    $("table").each(function() {
        var $this = $(this);
        var newrows = [];
        $this.find("tr").each(function(){
            var i = 0;
            $(this).find("td").each(function(){
                i++;
                if(newrows[i] === undefined) { newrows[i] = $("<tr></tr>"); }
                newrows[i].append($(this));
            });
        });
        //$this.find("tr").remove();
        $.each(newrows, function(){
            $this.append(this);
        });
    });

    return false;
});*/