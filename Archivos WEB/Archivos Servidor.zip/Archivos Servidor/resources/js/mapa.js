function draw(){
	//recorremos todos los id y comprobamos si existen en la tabla ocupa:
	var c = document.getElementById("FDI_01_016");
	var ctx = c.getContext("2d");
	//si hay un sitio ocupado, muestra la linea en el asiento
	//no he conseguido rellenar todo el cuadrado de un color, no se porque
	ctx.moveTo(0,0);
	ctx.lineTo(200,100);
	ctx.stroke();
}
//NO FUNCIONA-> QUIERO RECORRER TODOS LOS ID, para así por cada uno de ellos si esta en la tabla de ocupado lo pongo en rojo, si no en verde.
$(document).ready(function(){
    $("#id").each(function(){
        alert ($(this).text());
    });
});

function prueba(userObj){
    alert(userObj[0]);
    alert(userObj[1]);

}