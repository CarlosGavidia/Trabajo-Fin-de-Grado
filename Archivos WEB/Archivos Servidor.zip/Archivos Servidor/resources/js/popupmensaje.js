/*For display none when you click on * */
$( function() {
	$('.close').click(function() {
	if($("#popupMensaje").css("display") == "none") 
	{
		$("#popupMensaje").css('display', 'block');
	} else{
				$("#popupMensaje").css('display', 'none');
	}
});
});