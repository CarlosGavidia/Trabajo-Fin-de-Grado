﻿$( function() {
    $("#calle").on('keyup', function(){
        var value = $(this).val();
		var provin = $("#provincia").val();
        $.get('../../perfil/localizacionEvento.php',{'provincia':provin,'calle':value}, function(data){
			$("#mapa").html(data);
		});
    }).keyup();
	$("#provincia").change(function(){
        var provin = $(this).val();
		var value = $("#calle").val();
        $.get('../../perfil/localizacionEvento.php',{'provincia':provin,'calle':value}, function(data){
			$("#mapa").html(data);
		});
    });
}
);