
/**Header*/
// Used to toggle the menu on small screens when clicking on the menu button
function myFunction() {
    var x = document.getElementById("navDemo");
    if (x.className.indexOf("w3-show") == -1) {
        x.className += " w3-show";
    } else { 
        x.className = x.className.replace(" w3-show", "");
    }
}


/*Para el footer el bot�n cont�ctanos*/
    function contacto(path) {
        location.href = path;
    };

	
/*Funciones para avisar del uso de cookies */

$( function() {
//Si pulso en ok, pongo la cookie
$("#ok").click( function() {
	PonerCookie();
});

if(getCookie('eventsaviso')!="1"){
    document.getElementById("barraaceptacion").style.display="block";
}

});

function getCookie(c_name){
    var c_value = document.cookie;
    var c_start = c_value.indexOf(" " + c_name + "=");
    if (c_start == -1){
        c_start = c_value.indexOf(c_name + "=");
    }
    if (c_start == -1){
        c_value = null;
    }else{
        c_start = c_value.indexOf("=", c_start) + 1;
        var c_end = c_value.indexOf(";", c_start);
        if (c_end == -1){
            c_end = c_value.length;
        }
        c_value = unescape(c_value.substring(c_start,c_end));
    }
    return c_value;
}
 
function setCookie(c_name,value,exdays){
    var exdate=new Date();
    exdate.setDate(exdate.getDate() + exdays);
    var c_value=escape(value) + ((exdays==null) ? "" : "; expires="+exdate.toUTCString());
    document.cookie=c_name + "=" + c_value;
}
 

function PonerCookie(){
    setCookie('eventsaviso','1',365);
    document.getElementById("barraaceptacion").style.display="none";
}