function myMap(nombre,lon,lan) {
	
	var mapProp= {
		center:new google.maps.LatLng(lan, lon),
		zoom:14,
	};
	var myLatLong={lat:lan, lng:lon}
	var map=new google.maps.Map(document.getElementById("googleMap"),mapProp);
	var marker= new google.maps.Marker({
		position:myLatLong,
		map: map,
		title: nombre
	});
	var mensaje ='<div id="mensajeMaps">'+nombre+'</div>'
	var infowindow= new google.maps.InfoWindow({
		content: mensaje
	});
	marker.addListener('click',function(){
		infowindow.open(map,marker);
	});
}
