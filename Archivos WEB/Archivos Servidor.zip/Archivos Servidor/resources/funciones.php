﻿<?php
/*Función para añadir los CSS comunes*/
function anadirCSSComunes()
{
	return '<link rel="stylesheet" type="text/css" href="'. LIBRARY_PATH . 'font-awesome.min.css">'. PHP_EOL .
	'<link rel="stylesheet" type="text/css" media="all" href="'. LIBRARY_PATH . 'bootstrap.min.css">'. PHP_EOL .
	'<link rel="stylesheet" type="text/css" media="all" href="'. CSS_PATH . 'w3.css">' . PHP_EOL .
	'<link rel="stylesheet" type="text/css" media="all" href="'. CSS_PATH . 'styles.css">' . PHP_EOL .
	favicon();
}

/*Función para añadir el favicon*/
function favicon() {
	return '<link rel="icon" type="image/png" sizes="32x32" href="' . IMG_PATH . 'favicon-32x32.png">' . PHP_EOL .
	'<link rel="icon" type="image/png" sizes="16x16" href="' . IMG_PATH . 'favicon-16x16.png">' . PHP_EOL .
	'<link rel="shortcut icon" href="' . IMG_PATH . 'favicon.ico">' . PHP_EOL;
}

/*Función para añadir los JavaScript comunes*/
function anadirJSComunes()
{
	return '<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>' . PHP_EOL . 
	'<script src="'. LIBRARY_PATH . 'bootstrap.min.js"></script>' . PHP_EOL .
	'<script src="'. JS_PATH . 'headerYfooter.js"></script>' . PHP_EOL;
}

/*Añadir CSS no comunes*/
function anadirCSS($archivo)
{
	return '<link rel="stylesheet" type="text/css" media="all" href="' . CSS_PATH . $archivo . '">' . PHP_EOL;
}

/*Añadir JavaScript no comunes*/
function anadirJS($archivo)
{
	return '<script src="' . JS_PATH . $archivo . '"></script>' . PHP_EOL;	
}

/*Añadir librerías CSS*/
function anadirLibreriaCSS($archivo)
{
	return '<link rel="stylesheet" type="text/css" media="all" href="' . LIBRARY_PATH . $archivo . '">' . PHP_EOL;
}
/*Añadir librerías JavaScript*/
function anadirLibreriaJS($archivo)
{
	return '<script src="' . LIBRARY_PATH . $archivo . '"></script>' . PHP_EOL;	
}

/*Función para conectar de la BBDD*/
function conectarBBDD()
{
	global $config;
	return new mysqli($config['db']['host'],$config['db']['usuario'],$config['db']['contrasena'],$config['db']['nombreBBDD']);
}

/*Función para desconectar de la BBDD*/
function desconectarBBDD($db)
{

	$db->close();
}

/*Función para realizar una consulta '$sql' a la conexión '$db' */
function realizarConsulta($db,$sql)
{
	return $db->query($sql);
}

/*Función para realizar varias consultas '$sql' a la conexión '$db' */
function realizarConsultas($db,$sql)
{
	return $db->multi_query($sql);
}

function liberarConsulta($consulta)
{
	return $consulta->free();
}

/*Función para conocer si está logueado o no el usuario*/
function estaLogueado()
{
	return isset($_SESSION['biblioteca']) ? true : false;
}

/*Función para conseguir la información de un usuario*/
function buscarUsuario($db,$nombreUsuario)
{
	$mainSQL = "SELECT * FROM Usuarios WHERE usuario = '$nombreUsuario'";
	$consulta = realizarConsulta($db,$mainSQL);
	if($consulta)
	{
		$user = $consulta->fetch_object();
		return $user;
	}
	return null;
}

/*Función para tratar el texto y eliminar caracteres no adecuados */
function tratarTexto($texto){
	return htmlspecialchars(trim(strip_tags($texto)));
}
?>