﻿	<!-- Footer -->
	<footer id="myFooter">
		<div class="container">
			<div class="row">
				<div class="col-sm-3">
					<h2 class="logo"><img src=<?php echo IMG_PATH . "logo.png"; ?> alt="logo MontevichoSA" width=100 height=100/></h2>
				</div>
				<div class="col-sm-2">
					<h5>Explorar</h5>
					<ul>
						<li><a href=<?php echo ROOT_PATH . "descargaApp"; ?>>Descargar app</a></li>
						<li><a href=<?php echo ROOT_PATH . "quienesSomos"; ?>>Quiénes somos</a></li>
					</ul>
				</div>
				<?php if (!estaLogueado()) {?>
				<div class="col-sm-2">
					<h5>Comenzar</h5>
					<ul>
						<li><a href=<?php echo ROOT_PATH; ?>>Iniciar sesión</a></li>
					</ul>
				</div>
				<?php }?>
				<div class="col-sm-3">
					<div class="social-networks">
						<a href="https://twitter.com/MontevichoSA" target="_blank" class="twitter"><i class="fa fa-twitter"></i></a>
						<a href="https://www.facebook.com/SAMontevicho/" target="_blank" class="facebook"><i class="fa fa-facebook"></i></a>
						<a href="https://instagram.com/MontevichoSA" target="_blank" class="google"><i class="fa fa-instagram"></i></a>
					</div>
					<button type="button" onClick="window.location.href='mailto:administracion@biblioteko.es';" id="contactanos" class="btn btn-default">Contáctanos</button>
				</div>
			</div>
		</div>
		<div class="footer-copyright">
			<p>© 2018 Copyright Montevicho. Todos los derechos reservados.  </p>
		</div>
	</footer>