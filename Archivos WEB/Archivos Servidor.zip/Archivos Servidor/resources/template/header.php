﻿<?php

	//Iniciamos la sesión
	session_start();
	$usuario = (isset($_SESSION['usuario'])) ? $_SESSION['usuario']: null; 
	
	//Conexión de BBDD
	$db = conectarBBDD();
	
//Comprobamos si está logueado (si no es null)
if(estaLogueado()) { ?>
<!-- Navbar -->
<div class="w3-top">
  <div class="w3-bar header-color w3-card-2">
    <a class="w3-bar-item w3-button w3-padding-large w3-hide-medium w3-hide-large w3-left" href="javascript:void(0)" onclick="myFunction()" title="Toggle Navigation Menu"><i class="fa fa-bars fa-2x"></i></a>
   
    <a href="<?php echo ROOT_PATH ."buzon"; ?>" class="w3-bar-item w3-button w3-padding-large w3-hide-small header-item"><i class="fa fa-envelope fa-2x" aria-hidden="true"></i>BUZÓN DE SUGERENCIAS</a>
    <a href="<?php echo ROOT_PATH ."estadisticas"; ?>" class="w3-bar-item w3-button w3-padding-large w3-hide-small header-item"><i class="fa fa-bar-chart fa-2x" aria-hidden="true"></i>ESTADÍSTICAS</a>
	<div class="w3-bar-item w3-center w3-padding-small header-item-b">
    <img src="<?php echo IMG_PATH . 'logo.png'; ?>" alt="MontevichoSA"  class="logo">
    </div>	
    <a href="<?php echo ROOT_PATH ."horario"; ?>" class="w3-bar-item w3-button w3-padding-large w3-hide-small header-item"><i class="fa fa-clock-o fa-2x" aria-hidden="true"></i>ESTABLECER HORARIO</a>
	<a href="<?php echo ROOT_PATH . "logout"; ?>" class="w3-bar-item w3-button w3-padding-large w3-hide-small header-item"><i class="fa fa-times fa-2x" aria-hidden="true"></i>CERRAR SESIÓN</a>  
  </div>
</div>

<!-- Navbar on small screens -->
<div id="navDemo" class="w3-bar-block header-color w3-hide w3-hide-medium w3-hide-large w3-top">
  <a href="<?php echo ROOT_PATH ."buzon"; ?>" class="w3-bar-item w3-button w3-padding-large"><i class="fa fa-envelope w3-margin-right" aria-hidden="true"></i>BUZÓN DE SUGERENCIAS</a>
  <a href="<?php echo ROOT_PATH ."estadisticas"; ?>" class="w3-bar-item w3-button w3-padding-large"><i class="fa fa-bar-chart w3-margin-right" aria-hidden="true"></i>ESTADÍSTICAS</a>
  <a href="<?php echo ROOT_PATH ."horario"; ?>" class="w3-bar-item w3-button w3-padding-large"><i class="fa fa-clock-o w3-margin-right" aria-hidden="true"></i>ESTABLECER HORARIO</a>
  <a href="<?php echo ROOT_PATH ."logout"; ?>" class="w3-bar-item w3-button w3-padding-large"><i class="fa fa-times w3-margin-right" aria-hidden="true"></i>CERRAR SESIÓN</a>  
</div>

<?php
	$usuarioInfo = buscarUsuario($db,$usuario);
 } else { ?>

<!-- Navbar -->
<div class="w3-top">
  <div class="w3-bar header-color w3-card-2">
    <a class="w3-bar-item w3-button w3-padding-large w3-hide-medium w3-hide-large w3-left" href="javascript:void(0)" onclick="myFunction()" title="Toggle Navigation Menu"><i class="fa fa-bars fa-2x"></i></a>
    <p>
    <img src="<?php echo IMG_PATH . 'logo.png'; ?>" alt="MontevichoSA"  class="logo">
  </p>
  </div>
</div>

<!-- Navbar on small screens -->
<div id="navDemo" class="w3-bar-block header-color w3-hide w3-hide-medium w3-hide-large w3-top">
</div>


 <?php } ?>