﻿<?php
/*
This file contain all global information about our website configuration.
config contiene: db
db -> información para conectarse a la base de datos
*/
$config = [
"db" => [
"host" => "localhost",
"usuario" => "bibliot7_montevichosa",
"contrasena" => "TFGMasters_18",
"nombreBBDD" => "bibliot7_biblioteko"
]
];


/*Constantes predeterminadas del proyecto*/

defined('LIBRARY_PATH')
or define('LIBRARY_PATH', $path . 'resources/library/');

defined('TEMPLATES_PATH')
or define('TEMPLATES_PATH', $path . 'resources/template/');

defined('CSS_PATH')
or define('CSS_PATH', $path . 'resources/css/');

defined('ROOT_PATH')
or define('ROOT_PATH', $path);

defined('JS_PATH')
or define('JS_PATH', $path . 'resources/js/');

defined('IMG_PATH')
or define('IMG_PATH', $path . 'resources/img/');

//Ruta de la imagen predeterminada
defined('DEFAULT_PROFILE_IMG_PATH')
or define('DEFAULT_PROFILE_IMG_PATH',"../resources/img/profilePicture.png");

//Funciones
require_once('funciones.php');
?>