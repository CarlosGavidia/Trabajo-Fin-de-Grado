<?php
    
    require_once 'user.php';
   $path = '../';
include_once 'db-connect.php';
require_once 'comprobarUsuario.php';
require_once 'pip.php';
    
    $email = "";
    
    $contraseniaAntigua = "";
    
    $contraseniaNueva = "";
    $contraseniaNuevaRpt = "";
    
    if(isset($_POST['email'])){
        
        $email = $_POST['email'];
        
    }
    
    if(isset($_POST['contraseniaAntigua'])){
        
        $contraseniaAntigua = $_POST['contraseniaAntigua'];
        
    }
    
    if(isset($_POST['contraseniaNueva'])){
        
        $contraseniaNueva = $_POST['contraseniaNueva'];
        
    }
    if(isset($_POST['contraseniaNuevaRpt'])){
        
        $contraseniaNuevaRpt = $_POST['contraseniaNuevaRpt'];
        
    }
    
    
    $db =  mysqli_connect( 'localhost','bibliot7_montevichosa','TFGMasters_18','bibliot7_biblioteko');
    $userObject = new User();

  
    if(!empty($email) && !empty($contraseniaAntigua) && !empty($contraseniaNueva)&& !empty($contraseniaNuevaRpt)){
        if(strcmp($contraseniaNueva,$contraseniaNuevaRpt)==0){
        
            $existe = $userObject->isLoginExist($email, $contraseniaAntigua);
            
            if($existe==true){
                $json_array = $userObject->modificarContrasenia($email, $contraseniaNueva);
                echo json_encode($json_array);

            }
            else{
                $json_array['success'] = 1;
                $json_array['message'] = "Contrasenia anterior incorrecta";

                echo json_encode($json_array);
            }
            
        }
        else{
        $json_array['success'] = 3;
        $json_array['message'] = "No coinciden las nuevas";

        echo json_encode($json_array);
        }
    }
    else{
        $json_array['success'] = 0;
        $json_array['message'] = "Completa todos los campos.";

        echo json_encode($json_array);
    }

    
    ?>