<?php

require_once 'user.php';

$path = '../';
include_once 'db-connect.php';
require_once 'comprobarUsuario.php';

$db =  mysqli_connect( 'localhost','bibliot7_montevichosa','TFGMasters_18','bibliot7_biblioteko');

$biblioteca = "";
$json_planta1 = "";
$json_planta2 = "";
$json_planta3 = "";


if(isset($_POST['biblioteca'])){

	$biblioteca = $_POST['biblioteca'];

}

if(!empty($biblioteca))
{

	$query = "SELECT planta, dia, hora_inicio, hora_fin FROM horarios WHERE biblioteca='$biblioteca' order by planta, CASE dia WHEN 'Lunes' THEN 1 WHEN 'Martes' THEN 2 WHEN 'Miércoles' THEN 3 WHEN 'Jueves' THEN 4 WHEN 'Viernes' THEN 5 WHEN 'Sábado' THEN 6 WHEN 'Domingo' THEN 7 ELSE dia END";
	$consulta=mysqli_query($db,$query);




	$dias = ["lunes", "martes", "miercoles", "jueves", "viernes", "sabado", "domingo"];
	$dia = 1;
	$dia2 = 1;
	$dia3 = 1;
	$planta = 1;
	$planta_aux1="";
	$planta_aux2="";
	$planta_aux3="";
	$primera = 0;
	$segunda = 0;
	$tercera = 0;
	$num_fila = 1;


	if(mysqli_num_rows($consulta) > 0){
		$json_array['success'] = 1;
		$fila=mysqli_fetch_object($consulta);
		while ($fila!=NULL){
			if($num_fila < 8){
				if($planta_aux1 == ""){
					$planta_aux1 = $fila->planta;
					$json_planta1['nombre'] = $fila->planta;
				}

				
				$json_planta1["$fila->dia"."Abre"] = $fila->hora_inicio;
				$json_planta1["$fila->dia"."Cierra"] = $fila->hora_fin;

				if($fila->dia == "Domingo"){
					$json_array['planta1'] = $json_planta1;
				}
			

				$num_fila = $num_fila + 1;
				$fila=mysqli_fetch_object($consulta);
			}
			else if($num_fila < 15){
				if($planta_aux2 == ""){
					$planta_aux2 = $fila->planta;
					$json_planta2['nombre'] = $fila->planta;
				}

				
				$json_planta2["$fila->dia"."Abre"] = $fila->hora_inicio;
				$json_planta2["$fila->dia"."Cierra"] = $fila->hora_fin;
				if($fila->dia == "Domingo"){
					$json_array['planta2'] = $json_planta2;
				}
				

				$num_fila = $num_fila + 1;
				$fila=mysqli_fetch_object($consulta);

			}
			else if($num_fila < 23){
				if($planta_aux3 == ""){
					$planta_aux3 = $fila->planta;
					$json_planta3['nombre'] = $fila->planta;
				}

				
				$json_planta3["$fila->dia"."Abre"] = $fila->hora_inicio;
				$json_planta3["$fila->dia"."Cierra"] = $fila->hora_fin;
				if($fila->dia == "Domingo"){
					$json_array['planta3'] = $json_planta3;
				}
				


				$num_fila = $num_fila + 1;
				$fila=mysqli_fetch_object($consulta);
			}
		}
		echo json_encode($json_array);
		
	}
	else{
		$json_array['success'] = 0;
		$json_array['message'] = "mysqli_num_rows($consulta) == 0";
		echo json_encode($json_array);

	}


}

else
{
	$json_array['success'] = 0;
	$json_array['message'] = "empty($biblioteca)";
	echo json_encode($json_array);
}
?>