<?php
    
    require_once 'user.php';
    
    $email = "";
    
    $password = "";
    

    
    if(isset($_POST['email'])){
        
        $email = $_POST['email'];
        
    }
    
    if(isset($_POST['password'])){
        
        $password = $_POST['password'];
        
    }
    
    $db =  mysqli_connect( 'localhost','bibliot7_montevichosa','TFGMasters_18','bibliot7_biblioteko');
    
    $userObject = new User();
    
    // Login
    
    if(!empty($email) && !empty($password)){

        $puesto = "";
        $json_array = $userObject->loginUsers($email, $password);
        $query = " SELECT puesto, dentro FROM `ocupa` WHERE email = '$email' LIMIT 1 ";
        $consulta=mysqli_query($db,$query);
    
    	if(mysqli_num_rows($consulta) > 0){
    		$fila=mysqli_fetch_object($consulta);
        	$puesto=$fila->puesto;
        	$estudiando=$fila->dentro;
        }
        $json_array["puesto"] = $puesto;
        $json_array["estudiando"] = $estudiando;
        
        
        echo json_encode($json_array);
    }

    else{
        $json_array['success'] = 0;
        $json_array['message'] = "Completa todos los campos.";

        echo json_encode($json_array);
    }
    ?>