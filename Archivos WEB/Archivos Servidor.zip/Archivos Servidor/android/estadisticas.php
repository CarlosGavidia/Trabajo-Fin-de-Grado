<?php

require_once 'user.php';

$path = '../';
include_once 'db-connect.php';
require_once 'comprobarUsuario.php';

$db =  mysqli_connect( 'localhost','bibliot7_montevichosa','TFGMasters_18','bibliot7_biblioteko');

$biblioteca = "";
$email = "";

$estudiandoGeneral = "";
$descansandoGeneral = "";
$estudiandoEstudiante = "";
$descansandoEstudiante = "";
$plantas = "";


if(isset($_POST['biblioteca'])){

    $biblioteca = $_POST['biblioteca'];
}

if(isset($_POST['email'])){

    $email = $_POST['email'];
}



if(!empty($email) && !empty($biblioteca))
{

    $query = "SELECT COUNT(puesto) as numeroPuestos, SUBSTRING(puesto, 5,2) as planta from ocupa where SUBSTRING(puesto,1,3) = '$biblioteca' group by SUBSTRING(puesto, 5,2) order by planta";
    $consulta=mysqli_query($db,$query);
    $fila=mysqli_fetch_object($consulta);
    
    if(mysqli_num_rows($consulta) > 0){
        $plantas=$fila->planta.":";
        $plantas=$plantas.$fila->numeroPuestos;
        $fila=mysqli_fetch_object($consulta);
        while ($fila!=NULL){

            $plantas=$plantas.",".$fila->planta.":";
            $plantas=$plantas.$fila->numeroPuestos;
            
            $fila=mysqli_fetch_object($consulta);
        }
    }

    $query2 = "SELECT SUM(minutosPorEstudiante) as minutosTotalesMes, mes FROM ( SELECT ((SUM(duracion) / COUNT(DISTINCT(email))) / 60) as minutosPorEstudiante, SUBSTRING(DATE_FORMAT(fecha_inicio, '%d-%m-%Y'),4,7) as mes FROM `historico` WHERE estudiando = 1 AND SUBSTRING(puesto, 1, 3) = '$biblioteca' AND fecha_inicio > DATE_SUB(NOW(), INTERVAL 1 YEAR) GROUP by DATE_FORMAT(fecha_inicio, '%d-%m-%Y') ORDER BY DATE_FORMAT(fecha_inicio, '%Y-%m-%e')) AS SQ1 GROUP BY mes";
    $consulta2=mysqli_query($db,$query2);
    $fila2=mysqli_fetch_object($consulta2);
    
    if(mysqli_num_rows($consulta2) > 0){
        $estudiandoGeneral=$fila2->mes.":";
        $estudiandoGeneral=$estudiandoGeneral.$fila2->minutosTotalesMes;
        $fila2=mysqli_fetch_object($consulta2);
        while ($fila2!=NULL){

            $estudiandoGeneral=$estudiandoGeneral.",".$fila2->mes.":";
            $estudiandoGeneral=$estudiandoGeneral.$fila2->minutosTotalesMes;
            
            $fila2=mysqli_fetch_object($consulta2);
        }
    }

    $query3 = "SELECT SUM(minutosPorEstudiante) as minutosTotalesMes, mes FROM ( SELECT ((SUM(duracion) / COUNT(DISTINCT(email))) / 60) as minutosPorEstudiante, SUBSTRING(DATE_FORMAT(fecha_inicio, '%d-%m-%Y'),4,7) as mes FROM `historico` WHERE estudiando = 0 AND SUBSTRING(puesto, 1, 3) = '$biblioteca' AND fecha_inicio > DATE_SUB(NOW(), INTERVAL 1 YEAR) GROUP by DATE_FORMAT(fecha_inicio, '%d-%m-%Y') ORDER BY DATE_FORMAT(fecha_inicio, '%Y-%m-%e')) AS SQ1 GROUP BY mes";
    $consulta3=mysqli_query($db,$query3);
    $fila3=mysqli_fetch_object($consulta3);
    
    if(mysqli_num_rows($consulta3) > 0){
        $descansandoGeneral=$fila3->mes.":";
        $descansandoGeneral=$descansandoGeneral.$fila3->minutosTotalesMes;
        $fila3=mysqli_fetch_object($consulta3);
        while ($fila3!=NULL){

            $descansandoGeneral=$descansandoGeneral.",".$fila3->mes.":";
            $descansandoGeneral=$descansandoGeneral.$fila3->minutosTotalesMes;
            
            $fila3=mysqli_fetch_object($consulta3);
        }
    }

    $query4 = "SELECT SUM(minutosPorEstudiante) as minutosTotalesMes, mes FROM ( SELECT ((SUM(duracion) / COUNT(DISTINCT(email))) / 60) as minutosPorEstudiante, SUBSTRING(DATE_FORMAT(fecha_inicio, '%d-%m-%Y'),4,7) as mes FROM `historico` WHERE estudiando = 1 AND SUBSTRING(puesto, 1, 3) = '$biblioteca' AND email = '$email' AND fecha_inicio > DATE_SUB(NOW(), INTERVAL 1 YEAR) GROUP by DATE_FORMAT(fecha_inicio, '%d-%m-%Y') ORDER BY DATE_FORMAT(fecha_inicio, '%Y-%m-%e')) AS SQ1 GROUP BY mes";
    $consulta4=mysqli_query($db,$query4);
    $fila4=mysqli_fetch_object($consulta4);
    
    if(mysqli_num_rows($consulta4) > 0){
        $estudiandoEstudiante=$fila4->mes.":";
        $estudiandoEstudiante=$estudiandoEstudiante.$fila4->minutosTotalesMes;
        $fila4=mysqli_fetch_object($consulta4);
        while ($fila4!=NULL){

            $estudiandoEstudiante=$estudiandoEstudiante.",".$fila4->mes.":";
            $estudiandoEstudiante=$estudiandoEstudiante.$fila4->minutosTotalesMes;
            
            $fila4=mysqli_fetch_object($consulta4);
        }
    }

    $query5 = "SELECT SUM(minutosPorEstudiante) as minutosTotalesMes, mes FROM ( SELECT ((SUM(duracion) / COUNT(DISTINCT(email))) / 60) as minutosPorEstudiante, SUBSTRING(DATE_FORMAT(fecha_inicio, '%d-%m-%Y'),4,7) as mes FROM `historico` WHERE estudiando = 0 AND SUBSTRING(puesto, 1, 3) = '$biblioteca' AND email = '$email' AND fecha_inicio > DATE_SUB(NOW(), INTERVAL 1 YEAR) GROUP by DATE_FORMAT(fecha_inicio, '%d-%m-%Y') ORDER BY DATE_FORMAT(fecha_inicio, '%Y-%m-%e')) AS SQ1 GROUP BY mes";
    $consulta5=mysqli_query($db,$query5);
    $fila5=mysqli_fetch_object($consulta5);
    
    if(mysqli_num_rows($consulta5) > 0){
        $descansandoEstudiante=$fila5->mes.":";
        $descansandoEstudiante=$descansandoEstudiante.$fila5->minutosTotalesMes;
        $fila5=mysqli_fetch_object($consulta5);
        while ($fila5!=NULL){

            $descansandoEstudiante=$descansandoEstudiante.",".$fila5->mes.":";
            $descansandoEstudiante=$descansandoEstudiante.$fila5->minutosTotalesMes;
            
            $fila5=mysqli_fetch_object($consulta5);
        }
    }

    $json_array['success'] = 1;
    $json_array['estudiandoGeneral'] = $estudiandoGeneral;
    $json_array['descansandoGeneral'] = $descansandoGeneral;
    $json_array['estudiandoEstudiante'] = $estudiandoEstudiante;
    $json_array['descansandoEstudiante'] = $descansandoEstudiante;
    $json_array['plantas'] = $plantas;

    
    echo json_encode($json_array);
}
else
{
    $json_array['success'] = 0;
    echo json_encode($json_array);
}
?>