<?php

	$db =  mysqli_connect( 'localhost','bibliot7_montevichosa','TFGMasters_18','bibliot7_biblioteko');
	$query = "UPDATE puestos set ocupado = 0 where ID IN (select puesto from ocupa where email IN (select email from usuariosActivos where ultimaInfo is not null and ultimaInfo < DATE_SUB(NOW(), INTERVAL 20 MINUTE)))";
    $consulta=mysqli_query($db,$query);
    $query2 = "DELETE from ocupa where email in (select email from usuariosActivos where ultimaInfo is not null and ultimaInfo < DATE_SUB(NOW(), INTERVAL 20 MINUTE))";
    $consulta2=mysqli_query($db,$query2);
    $query3 = "DELETE from usuariosActivos where ultimaInfo is not null and ultimaInfo < DATE_SUB(NOW(), INTERVAL 20 MINUTE)";
    $consulta3=mysqli_query($db,$query3);

?>