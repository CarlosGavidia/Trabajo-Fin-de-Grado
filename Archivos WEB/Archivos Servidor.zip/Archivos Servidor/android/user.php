<?php
    
    include_once 'db-connect.php';
    use PHPMailer\PHPMailer\PHPMailer;
    use PHPMailer\PHPMailer\Exception;

    require 'Exception.php';
    require 'PHPMailer.php';
    require 'SMTP.php';
    
    class User{
        
        private $db;
        
        private $db_table = "usuarios";
        private $db_table_temp = "usuariostemp";


        public function __construct(){
            $this->db = new DbConnect();
        }
        
        public function isLoginExist($email, $password){
            
            $query = "select * from ".$this->db_table." where email = '$email'";

            $result = mysqli_query($this->db->getDb(), $query);
            $row = mysqli_fetch_assoc($result);
            
            if(mysqli_num_rows($result) > 0 and password_verify($password, $row['contrasenia'])){
                
                return true;
                
            }
            
            mysqli_close($this->db->getDb());
            
            return false;
            
        }

        public function estaActivado($email)
        {
            
            $query = "select * from ".$this->db_table." where email = '$email' AND activado Limit 1";
            
            $result = mysqli_query($this->db->getDb(), $query);
            
            if(mysqli_num_rows($result) > 0){
                
                mysqli_close($this->db->getDb());
                
                
                return true;
                
            }
            
            mysqli_close($this->db->getDb());
            
            return false;
            
        }
        
        public function isEmailUsernameExist($email){
            
            $query = "select * from ".$this->db_table." where email = '$email'";
            
            $result = mysqli_query($this->db->getDb(), $query);
            
            if(mysqli_num_rows($result) > 0){
                
                mysqli_close($this->db->getDb());
                
                return true;
                
            }
            
            
            return false;
            
        }
        
        public function isValidEmail($email){
            return filter_var($email, FILTER_VALIDATE_EMAIL) !== false;
        }
        
        //Comprueba que la contraeña tenga al menos 8 caracteres, una letra y un número
        public function checkPassword($pwd) {
            if ((strlen($pwd) < 8) || (!preg_match("#[0-9]+#", $pwd)) || (!preg_match("#[a-zA-Z]+#", $pwd))) {
                return false;
            }

            return true;
        }
        public function modificarContrasenia($email, $password){
            $strongPassword = $this->checkPassword($password);
            if($strongPassword){
                //HASHEAMOS LA CONTRASEÑA
                $password = password_hash($password, PASSWORD_DEFAULT);             
                $query2 = "UPDATE `usuarios` SET `contrasenia` = '$password' WHERE `email` = '$email' ";
                $consulta2=mysqli_query($this->db->getDb(), $query2);
                $json['success'] = 3;
                $json['message'] = "Se ha modificado";

            }
            else{
                $json['success'] = 2;
                $json['message'] = "Contrasenia debil";
                
            }
            return $json;
        }
        
        public function createNewRegisterUser($email, $password, $cPassword){
            
            
            $isExisting = $this->isEmailUsernameExist($email);
            
            
            if($isExisting){
                
                $json['success'] = 0;
                $json['message'] = "Este email ya está registrado.";
            }
            
            else
            {
                
                $isValid = $this->isValidEmail($email);
                
                if($isValid)
                {
                    if($password == $cPassword)
                    {
                        $strongPassword = $this->checkPassword($password);

                        if($strongPassword){
                            //HASHEAMOS LA CONTRASEÑA
                            $password = password_hash($password, PASSWORD_DEFAULT);
                            
                            $query = "insert into ".$this->db_table." (email, contrasenia, activado) values ('$email', '$password', 0) ";

                            //$hashedEmail = md5($email);
                            $hashedEmail = password_hash($email, PASSWORD_DEFAULT);
                            
                            
                            $query2 = " INSERT INTO ".$this->db_table_temp." (`email`, `emailHashed`) VALUES ('$email', '$hashedEmail') ";
                    
                            $inserted = mysqli_query($this->db->getDb(), $query);

                    
                            if($inserted == 1)
                            {

                                $inserted2 = mysqli_query($this->db->getDb(), $query2);

                                if($inserted2 == 1)
                                {
                                    $json['success'] = 1;
                                    $json['message'] = "Te has registrado con éxito. Te llegará un email para activar tu usuario.";



                                    $mail = new PHPMailer;
                                    //Tell PHPMailer to use SMTP
                                    $mail->isSMTP();
                                    //Enable SMTP debugging
                                    // 0 = off (for production use)
                                    // 1 = client messages
                                    // 2 = client and server messages
                                    $mail->SMTPDebug = 0;
                                    //Set the hostname of the mail server
                                    $mail->Host = 'smtp.gmail.com';
                                    // use
                                    // $mail->Host = gethostbyname('smtp.gmail.com');
                                    // if your network does not support SMTP over IPv6
                                    //Set the SMTP port number - 587 for authenticated TLS, a.k.a. RFC4409 SMTP submission
                                    $mail->Port = 587;
                                    //Set the encryption system to use - ssl (deprecated) or tls
                                    $mail->SMTPSecure = 'tls';
                                    //Whether to use SMTP authentication
                                    $mail->SMTPAuth = true;
                                    //Username to use for SMTP authentication - use full email address for gmail
                                    $mail->Username = "montevichosa@gmail.com";
                                    //Password to use for SMTP authentication
                                    $mail->Password = "TFGMasters_18";
                                    //Set who the message is to be sent from
                                    $mail->setFrom('montevichosa@gmail.com', 'Montevicho SA');
                                    //Set an alternative reply-to address
                                    $mail->addReplyTo('montevichosa@gmail.com', 'Montevicho SA');
                                    //Set who the message is to be sent to
                                    $mail->addAddress($email, $email);
                                    //Set the subject line
                                    $mail->Subject = 'Active su usuario';
                                    //Read an HTML message body from an external file, convert referenced images to embedded,
                                    //convert HTML into a basic plain-text alternative body
                                    //$mail->msgHTML(file_get_contents('contents.html'), __DIR__);
                                    //Replace the plain text body with one created manually
                                    $mail->Body = 'Hola '.$email.' pulsa en el siguiente enlace para activar tu usuario http://www.biblioteko.es/android/activarUsuario.php?id='.$hashedEmail;
                                    //Attach an image file
                                    //$mail->addAttachment('images/phpmailer_mini.png');
                                    //send the message, check for errors
                                    $mail->SMTPOptions = array(
                                    'ssl' => array(
                                    'verify_peer' => false,
                                    'verify_peer_name' => false,
                                    'allow_self_signed' => true
                                    )
                                    );
                                    $mail->send();

                                }

                                else
                                {
                                    $query3 = " DELETE FROM ".$this->db_table." where email = '$email' ";
                                    $borradoError = mysqli_query($this->db->getDb(), $query3);
                                    $json['success'] = 0;
                                    $json['message'] = "Ha ocurrido un problema. Si el problema persiste, por favor, póngase en contacto con los desarrolladores a través del apartado 'Contacto'."; 
                                }
                                
                        
                            }
                            else
                            {
                        
                                $json['success'] = 0;
                                $json['message'] = "Ha ocurrido un problema. Si el problema persiste, por favor, póngase en contacto con los desarrolladores a través del apartado 'Contacto'.";
                            }

                        }

                        else
                        {
                            $json['success'] = 0;
                            $json['message'] = "La contraseña debe contener al menos 8 caracteres, una letra y un número.";
                        }

                    }

                    else
                    {
                        $json['success'] = 0;
                        $json['message'] = "Las contraseñas no coinciden.";
                    }

                }

                else
                {
                    $json['success'] = 0;
                    $json['message'] = "La dirección de email introducida no es válida.";
                }
                
            }

            //mysqli_close($this->db_table);
            
            return $json;
            
        }
        
        public function loginUsers($email, $password){
            
            $json = array();
            
            $canUserLogin = $this->isLoginExist($email, $password);
            
            if($canUserLogin)
            {

                $usuarioActivado = $this->estaActivado($email);

                if($usuarioActivado)
                {
                    $json['success'] = 1;
                    $json['message'] = "Successfully logged in";
                }

                else
                {
                    $json['success'] = 0;
                    $json['message'] = "Este usuario aún no ha sido activado. Por favor, revisa tu correo electrónico.";
                }
            }
            else{
                $json['success'] = 0;
                $json['message'] = "Email y/o contraseña incorrectos.";
            }
            return $json;
        }
    }
    ?>