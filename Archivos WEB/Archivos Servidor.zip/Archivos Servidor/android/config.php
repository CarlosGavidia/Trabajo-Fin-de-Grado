<?php
    define("DB_HOST", "localhost");
    define("DB_USER", "bibliot7_montevichosa");
    define("DB_PASSWORD", "TFGMasters_18");
    define("DB_NAME", "bibliot7_biblioteko");
    ?>