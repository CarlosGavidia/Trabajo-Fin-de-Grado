<?php

	$db =  mysqli_connect( 'localhost','bibliot7_montevichosa','TFGMasters_18','bibliot7_biblioteko');
	$query = "DELETE from envia where fecha is not null and fecha < DATE_SUB(NOW(), INTERVAL 1 YEAR)";
    $consulta=mysqli_query($db,$query);

    $query2 = "DELETE from horarios where STR_TO_DATE(dia, '%e-%m-%Y') is not null and STR_TO_DATE(dia, '%e-%m-%Y') < DATE_SUB(NOW(), INTERVAL 1 DAY)";
    $consulta2=mysqli_query($db,$query2);

    $query3 = "INSERT into `historico` (email, fecha_inicio, duracion, estudiando, puesto) SELECT email, DATE_ADD(MAKEDATE(YEAR(fecha_inicio), 2), INTERVAL estudiando SECOND) , SUM(duracion) as duracion, estudiando, CONCAT('Tglobal',SUBSTRING(puesto, 1, 3)) FROM `historico` WHERE `fecha_inicio` < DATE_SUB(NOW(), INTERVAL 1 YEAR) GROUP BY YEAR(fecha_inicio), estudiando, email, SUBSTRING(puesto, 1, 3)";
    $consulta3=mysqli_query($db,$query3);

    $query4 = "DELETE FROM `historico` WHERE SUBSTRING(puesto, 4, 9) = 'global'";
    $consulta4=mysqli_query($db,$query4);

    $query5 = "DELETE FROM `historico` WHERE `fecha_inicio` < DATE_SUB(NOW(), INTERVAL 1 YEAR) and SUBSTRING(puesto, 1, 7) <> 'Tglobal'";
    $consulta5=mysqli_query($db,$query5);

    $query6 = "INSERT into `historico` (email, fecha_inicio, duracion, estudiando, puesto) SELECT email, DATE_ADD(MAKEDATE(YEAR(fecha_inicio), 1), INTERVAL estudiando SECOND) , duracion, estudiando, CONCAT(SUBSTRING(puesto, 8, 10),'global') FROM `historico` WHERE `fecha_inicio` < DATE_SUB(NOW(), INTERVAL 1 YEAR) and SUBSTRING(puesto, 1, 7) = 'Tglobal' GROUP BY YEAR(fecha_inicio), estudiando, email, SUBSTRING(puesto, 8, 10)";
    $consulta6=mysqli_query($db,$query6);

    $query7 = "DELETE FROM `historico` WHERE SUBSTRING(puesto, 1, 7) = 'Tglobal'";
    $consulta7=mysqli_query($db,$query7);

?>