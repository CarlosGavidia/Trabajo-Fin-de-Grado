<?php

require_once 'user.php';

$path = '../';
include_once 'db-connect.php';
require_once 'comprobarUsuario.php';

$db =  mysqli_connect( 'localhost','root','','tfgmasters');

$hora = "";
$email = "";


if(isset($_POST['hora'])){

    $hora = $_POST['hora'];
}

if(isset($_POST['email'])){

    $email = $_POST['email'];
}



if(!empty($email) && !empty($hora))
{

    $query = "SELECT * from `usuariosActivos` WHERE email = '$email' ";
    $consulta=mysqli_query($db,$query);
    if(mysqli_num_rows($consulta) > 0){
        $query2 = "UPDATE `usuariosActivos` SET `ultimaInfo` = '$hora' WHERE `usuariosActivos`.`email` = '$email' ";
        $consulta2=mysqli_query($db,$query2);
    }
    else
    {
        $query3 = "INSERT INTO usuariosActivos (`email`, `ultimaInfo`) VALUES ('$email', '$hora')";
        $consulta3=mysqli_query($db,$query3);
    }
    $query4 = "SELECT * from `ocupa` WHERE email = '$email' ";
    $consulta4=mysqli_query($db,$query4);
    if(mysqli_num_rows($consulta4) > 0)
        $json_array['ocupando'] = "SI";
    else
        $json_array['ocupando'] = "NO";

    $json_array['success'] = 1;
    echo json_encode($json_array);
}
else
{
    $json_array['success'] = 0;
    echo json_encode($json_array);
}
?>