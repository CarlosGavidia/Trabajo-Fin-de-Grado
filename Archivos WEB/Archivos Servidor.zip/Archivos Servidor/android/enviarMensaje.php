<?php
    
    require_once 'user.php';

$path = '../';
include_once 'db-connect.php';
require_once 'comprobarUsuario.php';
require_once 'pip.php';
    
    $asunto = "";
    
    $mensaje = "";
    $email = "";
    $fecha = "";
    

    
    if(isset($_POST['asunto'])){
        
        $asunto = $_POST['asunto'];
        
    }
    
    if(isset($_POST['mensaje'])){
        
        $mensaje = $_POST['mensaje'];
        
    }
    if(isset($_POST['email'])){
        
        $email = $_POST['email'];
        
    }
    
    if(isset($_POST['fecha'])){
        
        $fecha = $_POST['fecha'];
        
    }
    
    $db =  mysqli_connect( 'localhost','bibliot7_montevichosa','TFGMasters_18','bibliot7_biblioteko');
    
    $userObject = new User();
    
    // Login
    
    if(!empty($asunto) && !empty($mensaje)){
        $query1= "SELECT max(idMensaje) as ValorMayor FROM `envia`";
        $consulta5=mysqli_query($db,$query1);
        $id=mysqli_fetch_object($consulta5);
        $idMayor=$id->ValorMayor+1;
       

       $query5 = "INSERT INTO `envia` (`email`, `biblioteca`, `fecha`, `respuesta`, `asunto`, `contenido`, `idMensaje`) VALUES ('$email', 'FDI','$fecha','0', '$asunto','$mensaje','$idMayor') ";
        $consulta5=mysqli_query($db,$query5);
        $json_array['success'] = 1;
        $json_array['message'] = "Todo bien.";
        echo json_encode($json_array);
    }

    else{
        $json_array['success'] = 0;
        $json_array['message'] = "Completa todos los campos.";

        echo json_encode($json_array);
    }
    ?>