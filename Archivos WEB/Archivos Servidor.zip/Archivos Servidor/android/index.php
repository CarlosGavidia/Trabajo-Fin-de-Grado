<?php
    
    require_once 'user.php';
    
    $email = "";
    
    $password = "";
    
    $cPassword = "";
    
    if(isset($_POST['email'])){
        
        $email = $_POST['email'];
        
    }
    
    if(isset($_POST['password'])){
        
        $password = $_POST['password'];
        
    }
    
    if(isset($_POST['cPassword'])){
        
        $cPassword = $_POST['cPassword'];
        
    }
    
    
    
    $userObject = new User();
    
    // Registration
    
    if(!empty($email) && !empty($password) && !empty($cPassword)){
        
        $hashed_password = md5($password);

        $hashed_cPassword = md5($cPassword);
        
        $json_registration = $userObject->createNewRegisterUser($email, $hashed_password, $hashed_cPassword);
        
        echo json_encode($json_registration);
        
    }
    
    // Login
    
    if(!empty($email) && !empty($password) && empty($cPassword)){
        
        $hashed_password = md5($password);
        
        $json_array = $userObject->loginUsers($email, $hashed_password);
        
        echo json_encode($json_array);
    }
    ?>