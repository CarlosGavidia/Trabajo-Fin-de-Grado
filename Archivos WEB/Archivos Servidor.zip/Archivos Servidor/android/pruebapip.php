<?php

require_once 'pip.php';

$pointLocation = new pointLocation();
$points = array("40.452622 -3.733860");
$polygon = array("40.452699 -3.733947","40.452717 -3.733767", "40.452572 -3.733739", "40.452551 -3.733921", "40.452699 -3.733947");
// The last point's coordinates must be the same as the first one's, to "close the loop"
foreach($points as $key => $point) {
    echo "point " . ($key+1) . " ($point): " . $pointLocation->pointInPolygon($point, $polygon) . "<br>";
}
?>