<?php

require_once 'user.php';

$path = '../';
include_once 'db-connect.php';
require_once 'comprobarUsuario.php';

$db =  mysqli_connect( 'localhost','bibliot7_montevichosa','TFGMasters_18','bibliot7_biblioteko');

$puestoOcupado = "";
$inicioEstado = "";
$duracion = "";
$email = "";

if(isset($_POST['puestoOcupado'])){

    $puestoOcupado = $_POST['puestoOcupado'];
}

if(isset($_POST['inicioEstado'])){

    $inicioEstado = $_POST['inicioEstado'];
}

if(isset($_POST['duracion'])){

    $duracion = $_POST['duracion'];
}

if(isset($_POST['email'])){

    $email = $_POST['email'];
}

if(isset($_POST['estudiando'])){

    $estudiando = $_POST['estudiando'];
}


if(!empty($puestoOcupado) )
{

	$query = "UPDATE `puestos` SET `ocupado` = '0' WHERE `puestos`.`ID` = '$puestoOcupado' ";
	$consulta=mysqli_query($db,$query);
    $query2 = "DELETE from ocupa WHERE puesto = '$puestoOcupado' ";
    $consulta2=mysqli_query($db,$query2);
    $query3 = "INSERT INTO historico (`email`, `fecha_inicio`, `duracion`, `estudiando`, `puesto`) VALUES ('$email', '$inicioEstado', '$duracion', '$estudiando', '$puestoOcupado');";
    $consulta3 = mysqli_query($db,$query3);
    $json_array['success'] = 1;
    echo json_encode($json_array);
}
else
{
    $json_array['success'] = 0;
    echo json_encode($json_array);
}
?>