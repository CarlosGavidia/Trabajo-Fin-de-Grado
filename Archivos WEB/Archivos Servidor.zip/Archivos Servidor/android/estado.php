<?php

require_once 'user.php';

$path = '../';
include_once 'db-connect.php';
require_once 'comprobarUsuario.php';

$db =  mysqli_connect( 'localhost','bibliot7_montevichosa','TFGMasters_18','bibliot7_biblioteko');

$biblioteca = "";

$planta = "";



if(isset($_POST['biblioteca'])){

    $biblioteca = $_POST['biblioteca'];

}

if(isset($_POST['planta'])){

    $planta = $_POST['planta'];

}

if(isset($_POST['usuario'])){

    $usuario = $_POST['usuario'];
}

if(!empty($biblioteca) && !empty($planta) && !empty($usuario) )
    $json_array['puestoOcupado'] = usuarioOcupaPuesto($usuario);
else
    $json_array['puestoOcupado'] = "Error en la selección";

$puesto=$biblioteca . "_" . $planta . "%";

if(!empty($biblioteca) && !empty($planta)){

    $query = "SELECT ID FROM puestos where ocupado=0 and ID like '$puesto' ";
    $consulta=mysqli_query($db,$query);
    $puestoActual=mysqli_fetch_object($consulta);
    
    if(mysqli_num_rows($consulta) > 0){
        $ocupados=$puestoActual->ID;
        $puestoActual=mysqli_fetch_object($consulta);
        while ($puestoActual!=NULL){

            $ocupados=$ocupados.",".$puestoActual->ID;
            
            $puestoActual=mysqli_fetch_object($consulta);
        }
        $json_array['success'] = 1;
        $json_array['message'] = $ocupados;
        echo json_encode($json_array);

    }
    else{
        $json_array['success'] = 0;
        $json_array['message'] = "TODOS OCUPADOS";

        echo json_encode($json_array);
    }
}
    else{
        $json_array['success'] = 0;
        $json_array['message'] = "Error en la selección";

        echo json_encode($json_array);
    }
    ?>