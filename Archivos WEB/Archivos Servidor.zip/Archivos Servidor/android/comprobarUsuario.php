<?php
	
	function usuarioOcupaPuesto($usuario) {
		$puesto = "NINGUNO";
		$query = " SELECT puesto FROM `ocupa` WHERE email = '$usuario' LIMIT 1 ";
		$db =  mysqli_connect( 'localhost','bibliot7_montevichosa','TFGMasters_18','bibliot7_biblioteko');

    	$consulta=mysqli_query($db,$query);
    
    	if(mysqli_num_rows($consulta) > 0){
    		$fila=mysqli_fetch_object($consulta);
        	$puesto=$fila->puesto;
        }
        return $puesto;
    }
?>