<?php
    
	$path = '../';
	require_once($path."resources/config.php");
	$db = conectarBBDD();


    $idUsuario = $_GET["id"];
    echo $idUsuario;

    $sql="SELECT email FROM usuariostemp WHERE emailHashed = '$idUsuario' Limit 1";
	$consulta=realizarConsulta($db, $sql);
	if(mysqli_num_rows($consulta) == 1)
	{                
        $email=mysqli_fetch_object($consulta);
		$sql="DELETE FROM usuariostemp WHERE emailHashed = '$idUsuario'";
		$consulta=realizarConsulta($db, $sql);
		$sql="UPDATE `usuarios` SET `activado` = '1' WHERE `usuarios`.`email` = '$email->email' ";
		$consulta=realizarConsulta($db, $sql);
    }
    else
       	echo "User not found";
?>