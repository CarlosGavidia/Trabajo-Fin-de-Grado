<?php
    
    require_once 'user.php';
    
    $email = "";
    
    $password = "";
    
    $cPassword = "";
    
    if(isset($_POST['email'])){
        
        $email = $_POST['email'];
        
    }
    
    if(isset($_POST['password'])){
        
        $password = $_POST['password'];
        
    }
    
    if(isset($_POST['cPassword'])){
        
        $cPassword = $_POST['cPassword'];
        
    }
    
    
    
    $userObject = new User();
    
    // Registration
    
    if(!empty($email) && !empty($password) && !empty($cPassword)){
        
        
        $json_registration = $userObject->createNewRegisterUser($email, $password, $cPassword);
        
        echo json_encode($json_registration);
        
    }

    else{
        $json_registration['success'] = 0;
        $json_registration['message'] = "Completa todos los campos.";

        echo json_encode($json_registration);
    }
    
    ?>