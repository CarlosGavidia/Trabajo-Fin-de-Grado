<?php


require_once 'user.php';

$path = '../';
include_once 'db-connect.php';
require_once 'comprobarUsuario.php';
require_once 'pip.php';

$db =  mysqli_connect( 'localhost','bibliot7_montevichosa','TFGMasters_18','bibliot7_biblioteko');

$biblioteca = "";
$usuario = "";
$puestoAOcupar = "";
$latitud = null;
$longitud = null;

if(isset($_POST['biblioteca'])){

    $biblioteca = $_POST['biblioteca'];

}

if(isset($_POST['usuario'])){

    $usuario = $_POST['usuario'];

}

if(isset($_POST['puestoAOcupar'])){

    $puestoAOcupar = $_POST['puestoAOcupar'];

}

if(isset($_POST['latitud'])){

    $latitud = (double) $_POST['latitud'];

}

if(isset($_POST['longitud'])){

    $longitud = (double) $_POST['longitud'];

}


if(!empty($biblioteca) && !empty($usuario) && !empty($puestoAOcupar) && $latitud != null && $longitud != null)
{
    $query = "SELECT * FROM `ocupa` WHERE email = '$usuario' ";
    $consulta=mysqli_query($db,$query);
    if(mysqli_num_rows($consulta) == 0)
    {
        $query2 = "SELECT * FROM `puestos` WHERE ID = '$puestoAOcupar' and ocupado = 1";
        $consulta2=mysqli_query($db,$query2);
        if(mysqli_num_rows($consulta2) == 0)
        {
            $query3 = "SELECT * FROM `bibliotecas` WHERE siglas = '$biblioteca' ";
            $consulta3=mysqli_query($db,$query3);
            if(mysqli_num_rows($consulta3) > 0)
            {
                $coordBib=mysqli_fetch_object($consulta3);
                $pointLocation = new pointLocation();
                $A = $coordBib->NO_Lon." ".$coordBib->NO_Lat;
                $B = $coordBib->NE_Lon." ".$coordBib->NE_Lat;
                $C = $coordBib->SE_Lon." ".$coordBib->SE_Lat;
                $D = $coordBib->SO_Lon." ".$coordBib->SO_Lat;
                $poligono = array($A, $B, $C, $D, $A);
                $punto = $longitud." ".$latitud;
                $dentroOFuera = $pointLocation->pointInPolygon($punto, $poligono);
                if ($dentroOFuera != "outside")
                {
                    $query4 = "UPDATE `puestos` SET `ocupado` = '1' WHERE `puestos`.`ID` = '$puestoAOcupar' ";
                    $consulta4=mysqli_query($db,$query4);
                    $query5 = "INSERT INTO `ocupa` (`email`, `puesto`, `temporizador`, `dentro`) VALUES ('$usuario', '$puestoAOcupar', '0', '1') ";
                    $consulta5=mysqli_query($db,$query5);

                    $json_array['success'] = 1;
                    echo json_encode($json_array);
                }
                else
                {
                    $json_array['success'] = 2;
                    $json_array['message'] = $A;
                    echo json_encode($json_array);
                }
            }
            else
            {
                $json_array['success'] = 3;
                echo json_encode($json_array);
            }
        }
        else
        {
            $json_array['success'] = 0;
            echo json_encode($json_array);
        }
        
    }
    else
    {
        $json_array['success'] = 3;
        echo json_encode($json_array);
    }

}
else
{
    $json_array['success'] = 3;
    echo json_encode($json_array);
}
?>