<?php
    
    require_once 'user.php';

$path = '../';
include_once 'db-connect.php';
require_once 'comprobarUsuario.php';
require_once 'pip.php';
    
   
    $email = "";
   
    

    
    if(isset($_POST['email'])){
        
        $email = $_POST['email'];
        
    }
   
    
    $db =  mysqli_connect( 'localhost','bibliot7_montevichosa','TFGMasters_18','bibliot7_biblioteko');
    
    $userObject = new User();
    
    // Login
    
    if(!empty($email)){
        $query1= "SELECT asunto,fecha,idMensaje FROM envia where email = '$email' and respuesta =1";
        $consulta5=mysqli_query($db,$query1);
        $id=mysqli_fetch_object($consulta5);
        $total=$id->asunto.",".$id->fecha.",".$id->idMensaje;
        $id=mysqli_fetch_object($consulta5);
        while ($id!=NULL){
            $total= $total.",".$id->asunto.",".$id->fecha.",".$id->idMensaje;
            $id=mysqli_fetch_object($consulta5);
        }
       
        $json_array['success'] = 1;
        $json_array['message'] = $total;
        echo json_encode($json_array);
    }

    else{
        $json_array['success'] = 0;
        $json_array['message'] = "Campo email vacio.";

        echo json_encode($json_array);
    }
    ?>