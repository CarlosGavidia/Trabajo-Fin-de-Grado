﻿<?php

$path = '../';
require_once($path."resources/config.php");

	//Sesiones
	session_start();
	// remove all session variables
	session_unset(); 
	// destroy the session 	
	session_destroy(); 	
	header('Location: ' . ROOT_PATH);

?>