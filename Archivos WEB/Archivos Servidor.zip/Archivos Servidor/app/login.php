<?php
	//FALTARIA DEVOLVER AL USUARIO CUANDO NO SE HA PODIDO INSERTAR UNA NOTIFICACION.
	//Y TAMBIEN INICIAR SESSION AL REGISTRARSE
	$path = '../';
	require_once($path."resources/config.php");
	
	//Conexión de BBDD
	$db = conectarBBDD();
	
	if($db){
		$usuario=tratarTexto($_GET['usuario']);
		$password=tratarTexto($_GET['password']);
		if ($usuario!="" && $password!=""){
			$sql="select * from usuarios where email='$usuario'";
			$consulta=realizarConsulta($db,$sql);

			$numregistros=$consulta->num_rows;
			$obj = $consulta->fetch_object();
			//si existe ese usuario
			if ($numregistros!=0 and password_verify($password, $obj->contrasenia)){
				//iniciamos sesion
			}
			else{
				//notificar al usuario:ese usuario no existe
			}
		liberarConsulta($consulta);
		}
		else{
			//notificar al usuario: no has metido usuario o contraseña
		}
	}


//Cerramos la conexión
desconectarBBDD($db);
		

?>