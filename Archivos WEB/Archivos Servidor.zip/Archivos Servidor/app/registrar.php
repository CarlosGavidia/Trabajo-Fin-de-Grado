<?php
	
	//FALTARIA DEVOLVER AL USUARIO CUANDO NO SE HA PODIDO INSERTAR UNA NOTIFICACION.
	//Y TAMBIEN INICIAR SESSION AL REGISTRARSE
	$path = '../';
	require_once($path."resources/config.php");
	
	//Conexión de BBDD
	$db = conectarBBDD();
	
	if($db){
		$usuario=tratarTexto($_GET['usuario']);
		$password=tratarTexto($_GET['password']);
		$password2=tratarTexto($_GET['password2']);
		//comprobamos que el usuario haya completado los campos
		if ($usuario!="" && $password!="" && $password2!=""){
			//y que las contraseñas coincidan
			if ($password==$password2){
				$sql2="select * from usuarios where email='$usuario'";
				$consulta2=realizarConsulta($db,$sql2);
				$numregistros=$consulta2->num_rows;
				//si no existe ese usuario lo podemos insertar
				if ($numregistros==0){
					//Hasheamos las contraseñas
					$contrasena = password_hash($password, PASSWORD_DEFAULT);
					$sql="insert into usuarios (email,contrasenia) values ('$usuario','$contrasena')";
					$consulta=realizarConsulta($db,$sql);
					liberarConsulta($consulta);
				}
				else{
					//notificar al usuario: ese usuario ya existe
				}
				liberarConsulta($consulta2);
			}
			else{
				//notificar al usuario: no coinciden las contraseñas
			}
		}
		else{
			//notificar al usuario: no has metido usuario o contraseña
		}
	//Cerramos la conexión
	desconectarBBDD($db);
	}
?>