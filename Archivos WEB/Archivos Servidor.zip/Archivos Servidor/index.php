﻿<!--Incluimos funciones del header -->
<?php
	$path = '';
	require_once($path."resources/config.php");
?>

<!doctype html>
<html lang="es">
<head>
	<meta http-equiv="Content-Type" content="text/html;charset=utf-8">
	<meta charset="UTF-8">
	<title>Montevicho</title>
	<meta name="author" content="Montevicho">
	<meta name="viewport" content="width=device-width, initial-scale=1">
  <?php
	echo anadirCSSComunes(); 
	echo anadirCSS('loginStyle.css');
  ?>
  <!-- Google ReCaptcha-->
  <script src='https://www.google.com/recaptcha/api.js'></script>
</head>

<body>
	<!-- Cabecera -->
	<?php 
	require(TEMPLATES_PATH.'header.php');
	?>	
	
	<!--  Contenido  -->

	<?php if(!estaLogueado()) : ?>

		<div class="container">
			<div id="content">
				<form class="login" action ="login/login.php" method="post">
					<h1 class="login-title">Iniciar Sesión</h1>
					<input type="text" class="login-input-e" required placeholder="Siglas de la biblioteca" name="biblioteca" id ="biblioteca" autofocus>
					<input type="password" class="login-input-e" id="password" name="password" required placeholder="Contraseña">
					<input type="submit" value="Aceptar" name="submit" id="submit" class="login-button">
				</form>
				<div  id="notificacion" ><?php if(isset($_GET['msg_error'])) echo $_GET['msg_error']; ?></div>
			</div>
		</div>

	<?php else : ?>
		<?php
		$url= "Location:".ROOT_PATH."buzon/";
		header($url);
		?>

	<?php endif; ?>

	<!-- Footer -->
	<?php 
	require(TEMPLATES_PATH.'footer.php');
	?>	
	
	<!-- Scripts JavaScript-->
	<?php echo anadirJSComunes(); ?>
	
</body>
</html>