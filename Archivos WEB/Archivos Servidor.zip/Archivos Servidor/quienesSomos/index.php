<?php
	$path = '../';
	require_once($path."resources/config.php");
?>
<!doctype html>
<html lang="es">
<head>
  <meta http-equiv="Content-Type" content="text/html;charset=utf-8">
  <meta charset="UTF-8">
  <title>Quiénes somos</title>
  <meta name="author" content="Montevicho">
  <meta name="viewport" content="width=device-width, initial-scale=1">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<?php
	echo anadirCSSComunes();
 	echo anadirCSS('quienesSomosStyle.css');
	?>
</head>
<body>

  <!-- Cabecera -->
  <?php 
  require(TEMPLATES_PATH.'header.php');
  ?>	
  
	<!--  Contenido  -->
	<div class="container">
		<div id="content">
	   <!-- Introduction Row -->
	   <div class="row">
		<div class="col-lg-12">
		  <h1 class="page-header">Montevicho SA está compuesta por:</h1>
		</div>
	  </div>

	  <!-- Team Members Row -->
	  <div class="row">

		<div class="col-lg-4 col-sm-6 col-md-4 text-center">
		  <img class="img-circle img-responsive img-center" src="<?php echo IMG_PATH . 'carlos.jpg'; ?>" alt="Carlos" width="200" height="200"> 
		  <h3>Carlos Gavidia Ortiz</h3>
		  
		</div>
		<div class="col-lg-4 col-sm-6 col-md-4 text-center">
		  <img class="img-circle img-responsive img-center" src="<?php echo IMG_PATH . 'david.jpg'; ?>" alt="David" width="200" height="200"> 
		  <h3>David Gorricho San Juan</h3>
		</div>

		<div class="col-lg-4 col-sm-6 col-md-4 text-center">
		  <img class="img-circle img-responsive img-center" src="<?php echo IMG_PATH . 'ivan.jpg'; ?>" alt="Iván" width="200" height="200"> 
		  <h3>Iván Monterrubio Cerezo</h3>
		  
		</div>

		<div class="col-lg-4 col-sm-6 col-md-4 text-center">
		</div>
	  </div>

	</div>
	</div>	
	
	<!-- Footer -->
	<?php
 	require(TEMPLATES_PATH.'footer.php');
	?>	
	<!-- Scripts JavaScript-->
	<? echo anadirJSComunes(); ?>
</body>
</html>