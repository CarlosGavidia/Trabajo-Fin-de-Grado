﻿<!--Incluimos funciones del header -->
<?php
	$path = '../';
	require_once($path."resources/config.php");
	require_once("estadisticas.php");
?>

<!doctype html>
<html lang="es">
<head>
	<meta http-equiv="Content-Type" content="text/html;charset=utf-8">
	<meta charset="UTF-8">
	<title>Estadísticas</title>
	<meta name="author" content="Montevicho">
	<meta name="viewport" content="width=device-width, initial-scale=1">
  <?php
	echo anadirCSSComunes(); 
  ?>
</head>

<body>
	<!-- Cabecera -->
	<?php 
	require(TEMPLATES_PATH.'header.php');
	?>	
	
	<!--  Contenido  -->

	<?php if(estaLogueado()) : ?>

		<div class="container">
			<div id="content">
				<?php
				$rawdata = getAllInfo();

				//nos creamos dos arrays para almacenar el tiempo y el valor numérico
				$valoresArray;
				$timeArray;
				//en un bucle for obtenemos en cada iteración el valor númerico y 
				//el TIMESTAMP del tiempo y lo almacenamos en los arrays 
				for($i = 0 ;$i<count($rawdata);$i++){
				    $valoresArray[$i]= $rawdata[$i][0];
				    //OBTENEMOS EL TIMESTAMP
				    $time= $rawdata[$i][1];
				    date_default_timezone_set('Europe/Madrid');
				    $date = new DateTime($time);
				    //ALMACENAMOS EL TIMESTAMP EN EL ARRAY
				    $timeArray[$i] = $date->getTimestamp()*1000;
				}

				?>
				<div id="contenedor"></div>

				<script src="https://code.jquery.com/jquery.js"></script>
				<!-- Importo el archivo Javascript de Highcharts directamente desde su servidor -->
				<script src="http://code.highcharts.com/stock/highstock.js"></script>
				<script src="http://code.highcharts.com/modules/exporting.js"></script>
				<script>

				Highcharts.setOptions({
	    			global: {
	        			useUTC: false
	    			}
				});

				chartCPU = new Highcharts.StockChart({
				    chart: {
				        renderTo: 'contenedor'
				        //defaultSeriesType: 'spline'

				    },
				    rangeSelector : {
				        enabled: true
				    },
				    title: {
				        text: 'Gráfica'
				    },
				    xAxis: {
				        type: 'datetime',
				        minTickInterval: 24 * 3600 * 1000,
				        ordinal: false
				        //tickPixelInterval: 150,
				        //maxZoom: 20 * 1000
				    },
				    yAxis: {
				        minPadding: 0.2,
				        maxPadding: 0.2,
				        title: {
				            text: 'Minutos por estudiante',
				            margin: 10
				        }
				    },
				    series: [{
				        name: 'Minutos estudio',
				        data: (function() {
				                // generate an array of random data
				                var data = [];
				                <?php
				                    for($i = 0 ;$i<count($rawdata);$i++){
				                ?>
				                data.push([<?php echo $timeArray[$i];?>,<?php echo $valoresArray[$i];?>]);
				                <?php } ?>
				                return data;
				            })()
				    }],
				    credits: {
				            enabled: false
				    }
				});

				</script>   
			</div>
		</div>

	<?php else : ?>
		<?php
		$url= "Location:".ROOT_PATH;
		header($url);
		?>

	<?php endif; ?>

	<!-- Footer -->
	<?php 
	require(TEMPLATES_PATH.'footer.php');
	?>	
	
	<!-- Scripts JavaScript-->
	<? echo anadirJSComunes(); ?>
	
</body>
</html>