﻿<?php
//Llamada al archivo de configuración
$path = '../';
require_once($path."resources/config.php");

    //Devuelve un array multidimensional con el resultado de la consulta
    function getArraySQL($sql){
        //Creamos la conexión
        $db = conectarBBDD();
        //generamos la consulta
        if(!$result = realizarConsulta($db, $sql)) die();

        $rawdata = array();
        //guardamos en un array multidimensional todos los datos de la consulta
        $i=0;
        while($row = mysqli_fetch_array($result))
        {   
            //guardamos en rawdata todos los vectores/filas que nos devuelve la consulta
            $rawdata[$i] = $row;
            $i++;
        }
        //Cerramos la base de datos
        desconectarBBDD($db);
        //devolvemos rawdata
        return $rawdata;
    }

    function getAllInfo(){
        //Creamos la consulta
        $usuario=$_SESSION['biblioteca'];
        $sql = "SELECT ((SUM(duracion) / COUNT(DISTINCT(email))) / 60) as minutosPorEstudiante, DATE_FORMAT(fecha_inicio, '%e-%m-%Y') as dia FROM `historico` WHERE estudiando = 1 AND SUBSTRING(puesto, 1, 3) = '$usuario' GROUP by DATE_FORMAT(fecha_inicio, '%e-%m-%Y') ORDER BY DATE_FORMAT(fecha_inicio, '%Y-%m-%d')";
        //obtenemos el array con toda la información
        return getArraySQL($sql);
    }
?>