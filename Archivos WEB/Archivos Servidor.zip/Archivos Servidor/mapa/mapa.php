<?php	
	$path = '../';
	require_once($path."resources/config.php");
		
	//Conexión de BBDD
	$db = conectarBBDD();

	
if($db)
{
	$sql="delete from horarios where STR_TO_DATE(dia, '%e-%m-%Y') is not null and STR_TO_DATE(dia, '%e-%m-%Y') < DATE_SUB(NOW(), INTERVAL 1 DAY);
	 INSERT into `historico` (email, fecha_inicio, duracion, estudiando, puesto) SELECT email, DATE_ADD(MAKEDATE(YEAR(fecha_inicio), 2), INTERVAL estudiando SECOND) , SUM(duracion) as duracion, estudiando, CONCAT('Tglobal',SUBSTRING(puesto, 1, 3)) FROM `historico` WHERE `fecha_inicio` < DATE_SUB(NOW(), INTERVAL 1 YEAR) GROUP BY YEAR(fecha_inicio), estudiando, email, SUBSTRING(puesto, 1, 3);
	 DELETE FROM `historico` WHERE SUBSTRING(puesto, 4, 9) = 'global';
	 DELETE FROM `historico` WHERE `fecha_inicio` < DATE_SUB(NOW(), INTERVAL 1 YEAR) and SUBSTRING(puesto, 1, 7) <> 'Tglobal';
	 INSERT into `historico` (email, fecha_inicio, duracion, estudiando, puesto) SELECT email, DATE_ADD(MAKEDATE(YEAR(fecha_inicio), 1), INTERVAL estudiando SECOND) , duracion, estudiando, CONCAT(SUBSTRING(puesto, 8, 10),'global') FROM `historico` WHERE `fecha_inicio` < DATE_SUB(NOW(), INTERVAL 1 YEAR) and SUBSTRING(puesto, 1, 7) = 'Tglobal' GROUP BY YEAR(fecha_inicio), estudiando, email, SUBSTRING(puesto, 8, 10);
	 DELETE FROM `historico` WHERE SUBSTRING(puesto, 1, 7) = 'Tglobal';";
	$consulta=realizarConsultas($db,$sql);
	$notificacion .="La base de datos se ha limpiado correctamente.";
}

else
{
	$notificacion .="La base de datos no se ha conseguido limpiar. Contacte con el adminsitrador.";
}

//Cerramos la conexión
desconectarBBDD($db);

//Concateno el mensaje
$url= $url . $notificacion;

//Volvemos a la url que nos solicitó
header($url);
?>