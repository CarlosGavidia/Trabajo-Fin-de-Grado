﻿<!--Incluimos funciones del header -->
<?php
	$path = '../';
	require_once($path."resources/config.php");
?>

<!doctype html>
<html lang="es">
<head>
	<meta http-equiv="Content-Type" content="text/html;charset=utf-8">
	<meta charset="UTF-8">
	<title>Montevicho</title>
	<meta name="author" content="Montevicho">
	<meta name="viewport" content="width=device-width, initial-scale=1">
  <?php
	echo anadirCSSComunes(); 
	echo anadirCSS('mapa.css');
	echo anadirJS('mapa.js');
  ?>
</head>

<body onload="draw();">
	<!-- Cabecera -->
	<?php 
	require(TEMPLATES_PATH.'header.php');
	?>	
	
	<!--  Contenido  -->

<div class="container">
		<div id="content">

		<?php
			$usuario=$_SESSION['biblioteca'];
			$sql= "SELECT puesto FROM ocupa where substring(puesto, 1, 3) = '$usuario' ORDER BY puesto ASC";
			$consulta=mysqli_query($db, $sql);
			$puestosOcupados = $consulta->fetch_array(MYSQL_BOTH);
			$a = $puestosOcupados[1];
			echo $a;
		?>

		<script type="text/javascript"> prueba(<?php echo json_encode($puestosOcupados); ?>) </script>

			<div class="w3-row">
				<div class="w3-col s4 w3-center">
					<b>PLANTA 1</b>
				</div>
				<div class="w3-col s4 w3-center">
					<b>PLANTA 2</b>
				</div>
				<div class="w3-col s4 w3-center">
					<b>PLANTA 3</b>
				</div>
			</div>
			<br>
			<div class="w3-row">
				<div class="w3-col s4 w3-center"> <!--Planta 1-->
					<div class="w3-row">
						<div class="w3-col s9 w3-center">
						<p></p>
						</div>
						<div class="w3-col s3 w3-center">
							<div class="w3-col s3 w3-center">
								<canvas class="puesto" id="FDI_01_001" width="10" height="7"></canvas>
								<br><br> 
								<canvas class="puesto" id="FDI_01_002" width="10" height="7"></canvas>
							</div>
							<div class="w3-col s6 w3-center">
								<canvas id="mesa" width="30" height="50"></canvas>
							</div>
							<div class="w3-col s3 w3-center">
								<canvas class="puesto" id="FDI_01_003" width="10" height="7"></canvas>
								<br><br> 
								<canvas class="puesto" id="FDI_01_004" width="10" height="7"></canvas>
							</div>									
						</div>
					</div>

					<div class="w3-row">
						<div class="w3-col s9 w3-center">
							<div class="w3-col s1 w3-center">
								<br>
								<canvas class="puesto" id="FDI_01_005" width="10" height="7"></canvas>
								<br><br> 
								<canvas class="puesto" id="FDI_01_006" width="10" height="7"></canvas>
								<br><br> 
								<canvas class="puesto" id="FDI_01_007" width="10" height="7"></canvas>
								<br><br> 
								<canvas class="puesto" id="FDI_01_008" width="10" height="7"></canvas>
								<br><br> 
								<canvas class="puesto" id="FDI_01_009" width="10" height="7"></canvas>
								<br><br> 
								<canvas class="puesto" id="FDI_01_010" width="10" height="7"></canvas>
								<br><br> 
								<canvas class="puesto" id="FDI_01_011" width="10" height="7"></canvas>
								<br><br> 
								<canvas class="puesto" id="FDI_01_012" width="10" height="7"></canvas>
								<br><br> 
								<canvas class="puesto" id="FDI_01_013" width="10" height="7"></canvas>
								<br><br> 
								<canvas class="puesto" id="FDI_01_014" width="10" height="7"></canvas>
								<br><br> 
								<canvas class="puesto" id="FDI_01_015" width="10" height="7"></canvas>
							</div>
							<div class="w3-col s1 w3-center">
								<canvas id="mesa" width="20" height="370"></canvas>
							</div>
							<div class="w3-col s1 w3-center">
								<canvas id="mesa" width="20" height="370"></canvas>
							</div>
							<div class="w3-col s1 w3-center">
								<br>
								<canvas class="puesto" id="FDI_01_016" width="10" height="7" ></canvas>
								<br><br> 
								<canvas class="puesto" id="FDI_01_017" width="10" height="7"></canvas>
								<br><br> 
								<canvas class="puesto" id="FDI_01_001" width="10" height="7"></canvas>
								<br><br> 
								<canvas class="puesto" id="FDI_01_001" width="10" height="7"></canvas>
								<br><br> 
								<canvas class="puesto" id="FDI_01_001" width="10" height="7"></canvas>
								<br><br> 
								<canvas class="puesto" id="FDI_01_001" width="10" height="7"></canvas>
								<br><br> 
								<canvas class="puesto" id="FDI_01_001" width="10" height="7"></canvas>
								<br><br> 
								<canvas class="puesto" id="FDI_01_001" width="10" height="7"></canvas>
								<br><br> 
								<canvas class="puesto" id="FDI_01_001" width="10" height="7"></canvas>
								<br><br> 
								<canvas class="puesto" id="FDI_01_001" width="10" height="7"></canvas>
								<br><br> 
								<canvas class="puesto" id="FDI_01_001" width="10" height="7"></canvas>
							</div>
							<div class="w3-col s4 w3-center">
								<p></p>
							</div>

							<div class="w3-col s1 w3-center">
								<br><br><br><br><br> 
								<canvas class="puesto" id="FDI_01_001" width="10" height="7"></canvas>
								<br><br> 
								<canvas class="puesto" id="FDI_01_001" width="10" height="7"></canvas>
								<br><br> 
								<canvas class="puesto" id="FDI_01_001" width="10" height="7"></canvas>
								<br><br> 
								<canvas class="puesto" id="FDI_01_001" width="10" height="7"></canvas>
								<br><br> 
								<canvas class="puesto" id="FDI_01_001" width="10" height="7"></canvas>
								<br><br> 
								<canvas class="puesto" id="FDI_01_001" width="10" height="7"></canvas>
								<br><br> 
								<canvas class="puesto" id="FDI_01_001" width="10" height="7"></canvas>
								<br><br> 
								<canvas class="puesto" id="FDI_01_001" width="10" height="7"></canvas>
								<br><br> 
								<canvas class="puesto" id="FDI_01_001" width="10" height="7"></canvas>
							</div>
							<div class="w3-col s1 w3-center">
								<br><br><br><br>
								<canvas id="mesa" width="20" height="307"></canvas>
							</div>
							<div class="w3-col s1 w3-center">
								<canvas id="mesa" width="20" height="430"></canvas>
							</div>
							<div class="w3-col s1 w3-center">
								<br>
								<canvas class="puesto" id="FDI_01_001" width="10" height="7"></canvas>
								<br><br> 
								<canvas class="puesto" id="FDI_01_001" width="10" height="7"></canvas>
								<br><br> 
								<canvas class="puesto" id="FDI_01_001" width="10" height="7"></canvas>
								<br><br> 
								<canvas class="puesto" id="FDI_01_001" width="10" height="7"></canvas>
								<br><br> 
								<canvas class="puesto" id="FDI_01_001" width="10" height="7"></canvas>
								<br><br> 
								<canvas class="puesto" id="FDI_01_001" width="10" height="7"></canvas>
								<br><br> 
								<canvas class="puesto" id="FDI_01_001" width="10" height="7"></canvas>
								<br><br> 
								<canvas class="puesto" id="FDI_01_001" width="10" height="7"></canvas>
								<br><br> 
								<canvas class="puesto" id="FDI_01_001" width="10" height="7"></canvas>
								<br><br> 
								<canvas class="puesto" id="FDI_01_001" width="10" height="7"></canvas>
								<br><br> 
								<canvas class="puesto" id="FDI_01_001" width="10" height="7"></canvas>
								<br><br>
								<canvas class="puesto" id="FDI_01_001" width="10" height="7"></canvas>
								<br><br> 
								<canvas class="puesto" id="FDI_01_001" width="10" height="7"></canvas>
							</div>
						</div>
						<div class="w3-col s3 w3-center">
						<p></p>						
						</div>
					</div>
					<br>
					<div class="w3-row">
						<div class="w3-col s6 w3-center">
							<p></p>
						</div>
						<div class="w3-col s6 w3-center">
							<div class="w3-col s4 w3-center">
								<div id ="mesa4">
									<canvas class="puesto" id="FDI_01_001" width="10" height="7"></canvas>
									<canvas class="puesto" id="FDI_01_001" width="10" height="7"></canvas>
									<br>
									<canvas id="mesa" width="50" height="30"></canvas>
									<br>
									<canvas class="puesto" id="FDI_01_001" width="10" height="7"></canvas>
									<canvas class="puesto" id="FDI_01_001" width="10" height="7"></canvas>
								</div>
							</div>
							<div class="w3-col s8 w3-center">
								<div id ="mesa4">
									<canvas class="puesto" id="FDI_01_001" width="10" height="7"></canvas>
									<canvas class="puesto" id="FDI_01_001" width="10" height="7"></canvas>
									<canvas class="puesto" id="FDI_01_001" width="10" height="7"></canvas>
									<canvas class="puesto" id="FDI_01_001" width="10" height="7"></canvas>
									<br>
									<canvas id="mesa" width="100" height="30"></canvas>
									<br>
									<canvas class="puesto" id="FDI_01_001" width="10" height="7"></canvas>
									<canvas class="puesto" id="FDI_01_001" width="10" height="7"></canvas>
									<canvas class="puesto" id="FDI_01_001" width="10" height="7"></canvas>
									<canvas class="puesto" id="FDI_01_001" width="10" height="7"></canvas>
								</div>
							</div>
						</div>
					</div>


				</div>
				<div class="w3-col s4 w3-center"> <!--Planta 2-->
					
					<div class="w3-col s6 w3-center">
						<div class="w3-row">
							<div id ="mesa8">
								<canvas class="puesto" id="FDI_02_001" width="10" height="7"></canvas>
								<canvas class="puesto" id="FDI_02_001" width="10" height="7"></canvas>
								<canvas class="puesto" id="FDI_02_001" width="10" height="7"></canvas>
								<canvas class="puesto" id="FDI_02_001" width="10" height="7"></canvas>
								<br>
								<canvas id="mesa" width="100" height="30"></canvas>
								<br>
								<canvas class="puesto" id="FDI_02_001" width="10" height="7"></canvas>
								<canvas class="puesto" id="FDI_02_001" width="10" height="7"></canvas>
								<canvas class="puesto" id="FDI_02_001" width="10" height="7"></canvas>
								<canvas class="puesto" id="FDI_02_001" width="10" height="7"></canvas>
							</div>
						</div>
						<br>
						<div class="w3-row">
							<div id ="mesa8">
								<canvas class="puesto" id="FDI_02_001" width="10" height="7"></canvas>
								<canvas class="puesto" id="FDI_02_001" width="10" height="7"></canvas>
								<canvas class="puesto" id="FDI_02_001" width="10" height="7"></canvas>
								<canvas class="puesto" id="FDI_02_001" width="10" height="7"></canvas>
								<br>
								<canvas id="mesa" width="100" height="30"></canvas>
								<br>
								<canvas class="puesto" id="FDI_02_001" width="10" height="7"></canvas>
								<canvas class="puesto" id="FDI_02_001" width="10" height="7"></canvas>
								<canvas class="puesto" id="FDI_02_001" width="10" height="7"></canvas>
								<canvas class="puesto" id="FDI_02_001" width="10" height="7"></canvas>
							</div>
						</div>
						<br>
						<div class="w3-row">
							<div id ="mesa8">
								<canvas class="puesto" id="FDI_02_001" width="10" height="7"></canvas>
								<canvas class="puesto" id="FDI_02_001" width="10" height="7"></canvas>
								<canvas class="puesto" id="FDI_02_001" width="10" height="7"></canvas>
								<canvas class="puesto" id="FDI_02_001" width="10" height="7"></canvas>
								<br>
								<canvas id="mesa" width="100" height="30"></canvas>
								<br>
								<canvas class="puesto" id="FDI_02_001" width="10" height="7"></canvas>
								<canvas class="puesto" id="FDI_02_001" width="10" height="7"></canvas>
								<canvas class="puesto" id="FDI_02_001" width="10" height="7"></canvas>
								<canvas class="puesto" id="FDI_02_001" width="10" height="7"></canvas>
							</div>
						</div>
						<br>
						<div class="w3-row">
							<div id ="mesa8">
								<canvas class="puesto" id="FDI_02_001" width="10" height="7"></canvas>
								<canvas class="puesto" id="FDI_02_001" width="10" height="7"></canvas>
								<canvas class="puesto" id="FDI_02_001" width="10" height="7"></canvas>
								<canvas class="puesto" id="FDI_02_001" width="10" height="7"></canvas>
								<br>
								<canvas id="mesa" width="100" height="30"></canvas>
								<br>
								<canvas class="puesto" id="FDI_02_001" width="10" height="7"></canvas>
								<canvas class="puesto" id="FDI_02_001" width="10" height="7"></canvas>
								<canvas class="puesto" id="FDI_02_001" width="10" height="7"></canvas>
								<canvas class="puesto" id="FDI_02_001" width="10" height="7"></canvas>
							</div>
						</div>
		  			</div>

	  				<div class="w3-col s6 w3-center">
						<div class="w3-row">
							<div id ="mesa12">
								<canvas class="puesto" id="FDI_02_001" width="10" height="7"></canvas>
								<canvas class="puesto" id="FDI_02_001" width="10" height="7"></canvas>
								<canvas class="puesto" id="FDI_02_001" width="10" height="7"></canvas>
								<canvas class="puesto" id="FDI_02_001" width="10" height="7"></canvas>
								<canvas class="puesto" id="FDI_02_001" width="10" height="7"></canvas>
								<canvas class="puesto" id="FDI_02_001" width="10" height="7"></canvas>
								<br>
								<canvas id="mesa" width="170" height="30"></canvas>
								<br>
								<canvas class="puesto" id="FDI_02_001" width="10" height="7"></canvas>
								<canvas class="puesto" id="FDI_02_001" width="10" height="7"></canvas>
								<canvas class="puesto" id="FDI_02_001" width="10" height="7"></canvas>
								<canvas class="puesto" id="FDI_02_001" width="10" height="7"></canvas>
								<canvas class="puesto" id="FDI_02_001" width="10" height="7"></canvas>
								<canvas class="puesto" id="FDI_02_001" width="10" height="7"></canvas>
							</div>
						</div>
						<br>
						<div class="w3-row">
							<div id ="mesa12">
								<canvas class="puesto" id="FDI_02_001" width="10" height="7"></canvas>
								<canvas class="puesto" id="FDI_02_001" width="10" height="7"></canvas>
								<canvas class="puesto" id="FDI_02_001" width="10" height="7"></canvas>
								<canvas class="puesto" id="FDI_02_001" width="10" height="7"></canvas>
								<canvas class="puesto" id="FDI_02_001" width="10" height="7"></canvas>
								<canvas class="puesto" id="FDI_02_001" width="10" height="7"></canvas>
								<br>
								<canvas id="mesa" width="170" height="30"></canvas>
								<br>
								<canvas class="puesto" id="FDI_02_001" width="10" height="7"></canvas>
								<canvas class="puesto" id="FDI_02_001" width="10" height="7"></canvas>
								<canvas class="puesto" id="FDI_02_001" width="10" height="7"></canvas>
								<canvas class="puesto" id="FDI_02_001" width="10" height="7"></canvas>
								<canvas class="puesto" id="FDI_02_001" width="10" height="7"></canvas>
								<canvas class="puesto" id="FDI_02_001" width="10" height="7"></canvas>
							</div>
						</div>
						<br>
						<div class="w3-row">
							<div id ="mesa12">
								<canvas class="puesto" id="FDI_02_001" width="10" height="7"></canvas>
								<canvas class="puesto" id="FDI_02_001" width="10" height="7"></canvas>
								<canvas class="puesto" id="FDI_02_001" width="10" height="7"></canvas>
								<canvas class="puesto" id="FDI_02_001" width="10" height="7"></canvas>
								<canvas class="puesto" id="FDI_02_001" width="10" height="7"></canvas>
								<canvas class="puesto" id="FDI_02_001" width="10" height="7"></canvas>
								<br>
								<canvas id="mesa" width="170" height="30"></canvas>
								<br>
								<canvas class="puesto" id="FDI_02_001" width="10" height="7"></canvas>
								<canvas class="puesto" id="FDI_02_001" width="10" height="7"></canvas>
								<canvas class="puesto" id="FDI_02_001" width="10" height="7"></canvas>
								<canvas class="puesto" id="FDI_02_001" width="10" height="7"></canvas>
								<canvas class="puesto" id="FDI_02_001" width="10" height="7"></canvas>
								<canvas class="puesto" id="FDI_02_001" width="10" height="7"></canvas>
							</div>
						</div>
						<br>
						<div class="w3-row">
							<div id ="mesa12">
								<canvas class="puesto" id="FDI_02_001" width="10" height="7"></canvas>
								<canvas class="puesto" id="FDI_02_001" width="10" height="7"></canvas>
								<canvas class="puesto" id="FDI_02_001" width="10" height="7"></canvas>
								<canvas class="puesto" id="FDI_02_001" width="10" height="7"></canvas>
								<canvas class="puesto" id="FDI_02_001" width="10" height="7"></canvas>
								<canvas class="puesto" id="FDI_02_001" width="10" height="7"></canvas>
								<br>
								<canvas id="mesa" width="170" height="30"></canvas>
								<br>
								<canvas class="puesto" id="FDI_02_001" width="10" height="7"></canvas>
								<canvas class="puesto" id="FDI_02_001" width="10" height="7"></canvas>
								<canvas class="puesto" id="FDI_02_001" width="10" height="7"></canvas>
								<canvas class="puesto" id="FDI_02_001" width="10" height="7"></canvas>
								<canvas class="puesto" id="FDI_02_001" width="10" height="7"></canvas>
								<canvas class="puesto" id="FDI_02_001" width="10" height="7"></canvas>
							</div>
						</div>
						<br>
						<div class="w3-row">
							<div id ="mesa12">
								<canvas class="puesto" id="FDI_02_001" width="10" height="7"></canvas>
								<canvas class="puesto" id="FDI_02_001" width="10" height="7"></canvas>
								<canvas class="puesto" id="FDI_02_001" width="10" height="7"></canvas>
								<canvas class="puesto" id="FDI_02_001" width="10" height="7"></canvas>
								<canvas class="puesto" id="FDI_02_001" width="10" height="7"></canvas>
								<canvas class="puesto" id="FDI_02_001" width="10" height="7"></canvas>
								<br>
								<canvas id="mesa" width="170" height="30"></canvas>
								<br>
								<canvas class="puesto" id="FDI_02_001" width="10" height="7"></canvas>
								<canvas class="puesto" id="FDI_02_001" width="10" height="7"></canvas>
								<canvas class="puesto" id="FDI_02_001" width="10" height="7"></canvas>
								<canvas class="puesto" id="FDI_02_001" width="10" height="7"></canvas>
								<canvas class="puesto" id="FDI_02_001" width="10" height="7"></canvas>
								<canvas class="puesto" id="FDI_02_001" width="10" height="7"></canvas>
							</div>
						</div>
	  				</div>	

				</div>
				<div class="w3-col s4 w3-center"> <!--Planta 3-->
					
					<div class="w3-col s6 w3-center">
						<div class="w3-row">
							<div id ="mesa8">
								<canvas class="puesto" id="FDI_03_001" width="10" height="7"></canvas>
								<canvas class="puesto" id="FDI_03_001" width="10" height="7"></canvas>
								<canvas class="puesto" id="FDI_03_001" width="10" height="7"></canvas>
								<canvas class="puesto" id="FDI_03_001" width="10" height="7"></canvas>
								<br>
								<canvas id="mesa" width="100" height="30"></canvas>
								<br>
								<canvas class="puesto" id="FDI_03_001" width="10" height="7"></canvas>
								<canvas class="puesto" id="FDI_03_001" width="10" height="7"></canvas>
								<canvas class="puesto" id="FDI_03_001" width="10" height="7"></canvas>
								<canvas class="puesto" id="FDI_03_001" width="10" height="7"></canvas>
							</div>
						</div>
						<br>
						<div class="w3-row">
							<div id ="mesa8">
								<canvas class="puesto" id="FDI_03_001" width="10" height="7"></canvas>
								<canvas class="puesto" id="FDI_03_001" width="10" height="7"></canvas>
								<canvas class="puesto" id="FDI_03_001" width="10" height="7"></canvas>
								<canvas class="puesto" id="FDI_03_001" width="10" height="7"></canvas>
								<br>
								<canvas id="mesa" width="100" height="30"></canvas>
								<br>
								<canvas class="puesto" id="FDI_03_001" width="10" height="7"></canvas>
								<canvas class="puesto" id="FDI_03_001" width="10" height="7"></canvas>
								<canvas class="puesto" id="FDI_03_001" width="10" height="7"></canvas>
								<canvas class="puesto" id="FDI_03_001" width="10" height="7"></canvas>
							</div>
						</div>
						<br>
						<div class="w3-row">
							<div id ="mesa8">
								<canvas class="puesto" id="FDI_03_001" width="10" height="7"></canvas>
								<canvas class="puesto" id="FDI_03_001" width="10" height="7"></canvas>
								<canvas class="puesto" id="FDI_03_001" width="10" height="7"></canvas>
								<canvas class="puesto" id="FDI_03_001" width="10" height="7"></canvas>
								<br>
								<canvas id="mesa" width="100" height="30"></canvas>
								<br>
								<canvas class="puesto" id="FDI_03_001" width="10" height="7"></canvas>
								<canvas class="puesto" id="FDI_03_001" width="10" height="7"></canvas>
								<canvas class="puesto" id="FDI_03_001" width="10" height="7"></canvas>
								<canvas class="puesto" id="FDI_03_001" width="10" height="7"></canvas>
							</div>
						</div>
						<br>
						<div class="w3-row">
							<div id ="mesa8">
								<canvas class="puesto" id="FDI_03_001" width="10" height="7"></canvas>
								<canvas class="puesto" id="FDI_03_001" width="10" height="7"></canvas>
								<canvas class="puesto" id="FDI_03_001" width="10" height="7"></canvas>
								<canvas class="puesto" id="FDI_03_001" width="10" height="7"></canvas>
								<br>
								<canvas id="mesa" width="100" height="30"></canvas>
								<br>
								<canvas class="puesto" id="FDI_03_001" width="10" height="7"></canvas>
								<canvas class="puesto" id="FDI_03_001" width="10" height="7"></canvas>
								<canvas class="puesto" id="FDI_03_001" width="10" height="7"></canvas>
								<canvas class="puesto" id="FDI_03_001" width="10" height="7"></canvas>
							</div>
						</div>
						<br>
						<div class="w3-row">
							<div id ="mesa8">
								<canvas class="puesto" id="FDI_03_001" width="10" height="7"></canvas>
								<canvas class="puesto" id="FDI_03_001" width="10" height="7"></canvas>
								<canvas class="puesto" id="FDI_03_001" width="10" height="7"></canvas>
								<canvas class="puesto" id="FDI_03_001" width="10" height="7"></canvas>
								<br>
								<canvas id="mesa" width="100" height="30"></canvas>
								<br>
								<canvas class="puesto" id="FDI_03_001" width="10" height="7"></canvas>
								<canvas class="puesto" id="FDI_03_001" width="10" height="7"></canvas>
								<canvas class="puesto" id="FDI_03_001" width="10" height="7"></canvas>
								<canvas class="puesto" id="FDI_03_001" width="10" height="7"></canvas>
							</div>
						</div>
		  			</div>

	  				<div class="w3-col s6 w3-center">
						<div class="w3-row">
							<div id ="mesa12">
								<canvas class="puesto" id="FDI_03_001" width="10" height="7"></canvas>
								<canvas class="puesto" id="FDI_03_001" width="10" height="7"></canvas>
								<canvas class="puesto" id="FDI_03_001" width="10" height="7"></canvas>
								<canvas class="puesto" id="FDI_03_001" width="10" height="7"></canvas>
								<canvas class="puesto" id="FDI_03_001" width="10" height="7"></canvas>
								<canvas class="puesto" id="FDI_03_001" width="10" height="7"></canvas>
								<br>
								<canvas id="mesa" width="170" height="30"></canvas>
								<br>
								<canvas class="puesto" id="FDI_03_001" width="10" height="7"></canvas>
								<canvas class="puesto" id="FDI_03_001" width="10" height="7"></canvas>
								<canvas class="puesto" id="FDI_03_001" width="10" height="7"></canvas>
								<canvas class="puesto" id="FDI_03_001" width="10" height="7"></canvas>
								<canvas class="puesto" id="FDI_03_001" width="10" height="7"></canvas>
								<canvas class="puesto" id="FDI_03_001" width="10" height="7"></canvas>
							</div>
						</div>
						<br>
						<div class="w3-row">
							<div id ="mesa12">
								<canvas class="puesto" id="FDI_03_001" width="10" height="7"></canvas>
								<canvas class="puesto" id="FDI_03_001" width="10" height="7"></canvas>
								<canvas class="puesto" id="FDI_03_001" width="10" height="7"></canvas>
								<canvas class="puesto" id="FDI_03_001" width="10" height="7"></canvas>
								<canvas class="puesto" id="FDI_03_001" width="10" height="7"></canvas>
								<canvas class="puesto" id="FDI_03_001" width="10" height="7"></canvas>
								<br>
								<canvas id="mesa" width="170" height="30"></canvas>
								<br>
								<canvas class="puesto" id="FDI_03_001" width="10" height="7"></canvas>
								<canvas class="puesto" id="FDI_03_001" width="10" height="7"></canvas>
								<canvas class="puesto" id="FDI_03_001" width="10" height="7"></canvas>
								<canvas class="puesto" id="FDI_03_001" width="10" height="7"></canvas>
								<canvas class="puesto" id="FDI_03_001" width="10" height="7"></canvas>
								<canvas class="puesto" id="FDI_03_001" width="10" height="7"></canvas>
							</div>
						</div>
						<br>
						<div class="w3-row">
							<div id ="mesa12">
								<canvas class="puesto" id="FDI_03_001" width="10" height="7"></canvas>
								<canvas class="puesto" id="FDI_03_001" width="10" height="7"></canvas>
								<canvas class="puesto" id="FDI_03_001" width="10" height="7"></canvas>
								<canvas class="puesto" id="FDI_03_001" width="10" height="7"></canvas>
								<canvas class="puesto" id="FDI_03_001" width="10" height="7"></canvas>
								<canvas class="puesto" id="FDI_03_001" width="10" height="7"></canvas>
								<br>
								<canvas id="mesa" width="170" height="30"></canvas>
								<br>
								<canvas class="puesto" id="FDI_03_001" width="10" height="7"></canvas>
								<canvas class="puesto" id="FDI_03_001" width="10" height="7"></canvas>
								<canvas class="puesto" id="FDI_03_001" width="10" height="7"></canvas>
								<canvas class="puesto" id="FDI_03_001" width="10" height="7"></canvas>
								<canvas class="puesto" id="FDI_03_001" width="10" height="7"></canvas>
								<canvas class="puesto" id="FDI_03_001" width="10" height="7"></canvas>
							</div>
						</div>
						<br>
						<div class="w3-row">
							<div id ="mesa12">
								<canvas class="puesto" id="FDI_03_001" width="10" height="7"></canvas>
								<canvas class="puesto" id="FDI_03_001" width="10" height="7"></canvas>
								<canvas class="puesto" id="FDI_03_001" width="10" height="7"></canvas>
								<canvas class="puesto" id="FDI_03_001" width="10" height="7"></canvas>
								<canvas class="puesto" id="FDI_03_001" width="10" height="7"></canvas>
								<canvas class="puesto" id="FDI_03_001" width="10" height="7"></canvas>
								<br>
								<canvas id="mesa" width="170" height="30"></canvas>
								<br>
								<canvas class="puesto" id="FDI_03_001" width="10" height="7"></canvas>
								<canvas class="puesto" id="FDI_03_001" width="10" height="7"></canvas>
								<canvas class="puesto" id="FDI_03_001" width="10" height="7"></canvas>
								<canvas class="puesto" id="FDI_03_001" width="10" height="7"></canvas>
								<canvas class="puesto" id="FDI_03_001" width="10" height="7"></canvas>
								<canvas class="puesto" id="FDI_03_001" width="10" height="7"></canvas>
							</div>
						</div>
	  				</div>	

				</div>


			</div>

		</div>
</div>









	<!-- Footer -->
	<?php 
	require(TEMPLATES_PATH.'footer.php');
	?>	
	
	<!-- Scripts JavaScript-->
	<? echo anadirJSComunes(); ?>
	
</body>
</html>