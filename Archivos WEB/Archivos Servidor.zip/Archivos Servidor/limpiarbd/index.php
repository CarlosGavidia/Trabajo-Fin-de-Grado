﻿<!--Incluimos funciones del header -->
<?php
	$path = '../';
	require_once($path."resources/config.php");
?>

<!doctype html>
<html lang="es">
<head>
	<meta http-equiv="Content-Type" content="text/html;charset=utf-8">
	<meta charset="UTF-8">
	<title>Montevicho</title>
	<meta name="author" content="Montevicho">
	<meta name="viewport" content="width=device-width, initial-scale=1">
  <?php
	echo anadirCSSComunes(); 
	echo anadirCSS('loginStyle.css');
  ?>
</head>

<body>
	<!-- Cabecera -->
	<?php 
	require(TEMPLATES_PATH.'header.php');
	?>	
	
	<!--  Contenido  -->
	<div class="container">
		<div id="content">
			<form class="limpiarBD" action ="limpiarBD.php" method="post">
				<input type="submit" value="Limpiar base de datos" name="submit" id="submit" class="login-button">
			</form>
			<div  id="notificacion" ><?php if(isset($_GET['msg_error'])) echo $_GET['msg_error']; ?></div>
		</div>
	</div>
	<!-- Footer -->
	<?php 
	require(TEMPLATES_PATH.'footer.php');
	?>	
	
	<!-- Scripts JavaScript-->
	<? echo anadirJSComunes(); ?>
	
</body>
</html>