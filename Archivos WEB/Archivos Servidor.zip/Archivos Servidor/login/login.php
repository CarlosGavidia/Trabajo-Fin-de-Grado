﻿<?php	
	$path = '../';
	require_once($path."resources/config.php");
		
	//Conexión de BBDD
	$db = conectarBBDD();

	//Para volver al registro
	$url = "Location:" . ROOT_PATH . "?msg_error=";

	//Para enviar la notificación
	$notificacion='';

	session_start();
	
if($db)
{
	//Recojo los valores del registro
	$biblioteca=tratarTexto($_POST['biblioteca']);
	$password=tratarTexto($_POST['password']);
	
	
	if ($biblioteca!="" && $password!="" ){
	
	//saca todos las bibliotecas registradas con esas siglas y esa contraseña
	$sql="select * from bibliotecas where siglas='$biblioteca'";
	$consulta=realizarConsulta($db,$sql);

	$numregistros=$consulta->num_rows;
	$obj = $consulta->fetch_object();
	//si existe ese usuario
	if ($numregistros!=0 and password_verify($password, $obj->contrasenia)){

		//se crea la sesion y se guarda las variables de usuario y contraseña
		$_SESSION['biblioteca']=$biblioteca;
		$_SESSION['contrasena']=$password;
		header('Location:' . ROOT_PATH . "buzon");
		exit();
		
	}
	else{
		$notificacion .="Siglas y/o contraseña incorrectos";
	}
	liberarConsulta($consulta);
	}
}

//Cerramos la conexión
desconectarBBDD($db);

//Concateno el mensaje de error
$url= $url . $notificacion;

//Volvemos a la url que nos solicitó
header($url);
?>